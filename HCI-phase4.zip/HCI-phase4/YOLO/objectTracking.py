import cv2
import time
import torch
from ultralytics import YOLO
from typing import Optional
from collections import Counter
from enum import Enum

# =========================================
# CONSTANTS
# =========================================
MODE_NONE = 0
MODE_LENS = 1
MODE_BLUSH = 2
MODE_LIP = 3

# ControlPriority definition (mirrors main.py)
class ControlPriority(Enum):
    TUIO = 4      # Highest - explicit rotation
    OBJECT = 3    # Explicit product swipe
    GESTURE = 2   # Intentional hand gesture
    EMOTION = 1   # Passive emotion change
    NONE = 0


# =========================================
# GPU CHECK
# =========================================
def is_gpu_available():
    """Check if GPU is available for YOLO"""
    if torch.cuda.is_available():
        print(f"[GPU] CUDA available: {torch.cuda.get_device_name(0)}")
        print(f"[GPU] CUDA version: {torch.version.cuda}")
        return True
    elif hasattr(torch.backends, 'mps') and torch.backends.mps.is_available():
        print(f"[GPU] MPS available (Apple Silicon)")
        return True
    else:
        print("[GPU] No GPU detected, using CPU")
        return False

# =========================================
# DETECTOR CLASS
# =========================================
class ObjectSwipeDetector:
    def __init__(self, model_path="YOLO/best.pt"):
        # Check GPU availability
        self.use_gpu = is_gpu_available()
        
        # Load model
        self.model = YOLO(model_path)
        
        # Print available classes
        print(f"[YOLO] Model classes: {self.model.names}")
        
        # Move to GPU if available
        if self.use_gpu and torch.cuda.is_available():
            self.model.to('cuda')
            print("[GPU] YOLO model loaded on CUDA")
        
        self.previous_x: Optional[float] = None
        self.previous_time: float = 0
        self.swipe_threshold = 50  # Reduced for easier testing
        self.cooldown = 0
        self.last_swipe_time = 0
        self.consecutive_detections = 0
        self.min_detections_for_control = 2
        
        # Track control state
        self.control_active = False
        self.control_start_time = 0
        self.last_detected_class = None
        
        # Performance tracking
        self.inference_times = []
        self.frame_count = 0
        
    def map_to_mode(self, class_name):
        """Map YOLO class name to app mode"""
        if class_name == "lipstick":
            return MODE_LIP
        elif class_name == "blusher":
            return MODE_BLUSH
        else:
            return None
    
    def update(self, frame, app_state):
        """Update with improved detection and longer control lock"""
        if self.cooldown > 0:
            self.cooldown -= 1
        
        h, w = frame.shape[:2]
        
        # Process at reduced resolution
        small_frame = cv2.resize(frame, (320, 320))
        scale_x = w / 320
        scale_y = h / 320
        
        # Time inference
        start_time = time.time()
        
        # Run inference
        results = self.model(
            small_frame,
            conf=0.3,
            iou=0.45,
            imgsz=320,
            verbose=False,
            device='cuda' if self.use_gpu and torch.cuda.is_available() else 'cpu'
        )
        
        # Track performance
        inference_time = (time.time() - start_time) * 1000
        self.inference_times.append(inference_time)
        if len(self.inference_times) > 30:
            self.inference_times.pop(0)
        
        self.frame_count += 1
        if self.frame_count % 60 == 0:
            avg_time = sum(self.inference_times) / len(self.inference_times)
            gpu_str = "GPU" if self.use_gpu else "CPU"
            print(f"[{gpu_str}] Avg inference: {avg_time:.1f}ms ({1000/avg_time:.1f} FPS)")
        
        detected_mode = None
        center_x = None
        current_detection = False
        class_name = None
        
        if results[0].boxes is not None and len(results[0].boxes):
            # Get highest confidence detection
            best_box = max(results[0].boxes, key=lambda b: b.conf[0])
            class_id = int(best_box.cls[0])
            class_name = self.model.names[class_id]
            confidence = float(best_box.conf[0])
            
            if confidence > 0.35:
                current_detection = True
                x1, y1, x2, y2 = best_box.xyxy[0]
                x1 = int(x1 * scale_x)
                x2 = int(x2 * scale_x)
                y1 = int(y1 * scale_y)
                y2 = int(y2 * scale_y)
                
                # Ensure bounds
                x1 = max(0, min(x1, w))
                x2 = max(0, min(x2, w))
                y1 = max(0, min(y1, h))
                y2 = max(0, min(y2, h))
                
                # Draw detection box
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                cv2.putText(frame, f"{class_name} ({confidence:.2f})",
                           (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX,
                           0.6, (0, 255, 0), 2)
                
                
                center_x = (x1 + x2) // 2
                detected_mode = self.map_to_mode(class_name)
                
                # Track consecutive detections of SAME class
                if self.last_detected_class == class_name:
                    self.consecutive_detections += 1
                else:
                    self.consecutive_detections = 1
                    self.last_detected_class = class_name
                
                # Show detection info
                mode_name = "LIP" if detected_mode == MODE_LIP else "BLUSH" if detected_mode == MODE_BLUSH else "NONE"
                cv2.putText(frame, f"Detected: {mode_name} (stable: {self.consecutive_detections})",
                           (x1, y2 + 45), cv2.FONT_HERSHEY_SIMPLEX,
                           0.5, (255, 255, 0), 1)
        
        # CRITICAL: Only process swipe if the detected product matches the CURRENT active mode
        if detected_mode is not None and detected_mode == app_state.current_mode:
            
            
            # We have a consistent detection
            if self.consecutive_detections >= self.min_detections_for_control:
                # Request control with FORCE flag to ensure it takes over
                if app_state.active_controller != ControlPriority.OBJECT:
                    app_state.request_control(ControlPriority.OBJECT, force=True)
                    self.control_active = True
                    self.control_start_time = time.time()
                    print(f"[OBJECT] TAKING CONTROL for {class_name}")
                
                
                
                # Process swipe
                current_time = time.time()
                
                # Draw movement guide
                if self.previous_x is not None:
                    cv2.arrowedLine(frame, (self.previous_x, h//2), (center_x, h//2), 
                                   (0, 255, 255), 3, tipLength=0.3)
                
                # Check for swipe (longer cooldown for easier testing)
                if self.previous_x is not None and self.cooldown == 0:
                    movement = center_x - self.previous_x
                    dt = current_time - self.previous_time
                    
                    if dt > 0 and dt < 0.5:
                        
                        
                        # Right to left swipe (next shade)
                        if movement < -self.swipe_threshold:
                            app_state.current_shade = (app_state.current_shade + 1) % 4
                            self.cooldown = 40  # Longer cooldown (1.3 seconds)
                            self.last_swipe_time = current_time
                            print(f"[OBJECT] ✅ SWIPE RIGHT→LEFT detected! Shade: {app_state.current_shade}")
                            
                        
                        # Left to right swipe (previous shade)
                        elif movement > self.swipe_threshold:
                            app_state.current_shade = (app_state.current_shade - 1) % 4
                            self.cooldown = 40  # Longer cooldown (1.3 seconds)
                            self.last_swipe_time = current_time
                            print(f"[OBJECT] ✅ SWIPE LEFT→RIGHT detected! Shade: {app_state.current_shade}")
                            
                
                self.previous_x = center_x
                self.previous_time = current_time
        else:
            # Reset tracking if product doesn't match
            self.previous_x = None
            if detected_mode is not None:
                # Show wrong product message
                cv2.putText(frame, f"Wrong product! Show a {app_state.current_filter_name}",
                           (10, h - 50), cv2.FONT_HERSHEY_SIMPLEX,
                           0.5, (0, 0, 255), 1)
        
        # Draw control status on frame
        if app_state.active_controller == ControlPriority.OBJECT:
            cv2.putText(frame, f"ACTIVE: OBJECT (shade: {app_state.current_shade})",
                       (10, 120), cv2.FONT_HERSHEY_SIMPLEX,
                       0.6, (0, 255, 255), 2)
        elif self.control_active and time.time() - self.control_start_time > 2:
            self.control_active = False
        
        # Ensure shade within bounds
        if app_state.current_shade < 0:
            app_state.current_shade = 0
        if app_state.current_shade > 3:
            app_state.current_shade = 3
        
        return frame