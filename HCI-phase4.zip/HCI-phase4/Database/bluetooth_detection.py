import bluetooth
import time
import cv2
import numpy as np
import threading
from collections import defaultdict

scan_result = None
scan_done = False


def load_users():
    users = []
    with open("Database/users.txt", "r", encoding="utf-8") as f:
        for line in f:
            name, age, device, mac ,room= line.strip().split(",")
            users.append({
                "name": name.strip(),
                "device": device.strip().lower(),
                "mac": mac.strip().upper(),
                "room": room.strip().upper()
            })
    return users


def scan_bluetooth():
    global scan_result, scan_done

    counts = defaultdict(int)
    names = {}

    rounds = 4
    for i in range(rounds):
        print(f"\nScan round {i + 1}...")
        devices = bluetooth.discover_devices(duration=3, lookup_names=True)

        if not devices:
            print("No devices found this round.")
        for mac, name in devices:
            mac = mac.upper()
            name = (name or "").lower()

            counts[mac] += 1
            names[mac] = name

            print(f"Found: {name} ({mac})")

        time.sleep(1)  # pause a bit between rounds

    scan_result = [
        {"mac": m, "name": names.get(m, ""), "score": c}
        for m, c in counts.items()
    ]

    scan_done = True


def match_user(device, users):
    for u in users:
        if u["mac"] == device["mac"]:
            return u
        if u["device"] in device["name"] or device["name"] in u["device"]:
            return u
    return None


def draw_center_text(img, text, y, color=(0, 0, 0), scale=1):
    h, w = img.shape[:2]
    size = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, scale, 2)[0]
    x = (w - size[0]) // 2
    cv2.putText(img, text, (x, y),
                cv2.FONT_HERSHEY_SIMPLEX,
                scale, color, 2, cv2.LINE_AA)


def window_closed(name):
    return cv2.getWindowProperty(name, cv2.WND_PROP_VISIBLE) < 1


def login_screen():
    global scan_done, scan_result

    users = load_users()
    scan_done = False
    scan_result = None

    threading.Thread(target=scan_bluetooth, daemon=True).start()

    window = "LOGIN"
    cv2.namedWindow(window)

    start_time = time.time()

    while True:
        frame = np.ones((500, 900, 3), dtype=np.uint8) * 255
        t = time.time() - start_time

        draw_center_text(frame, "LOGIN USING BLUETOOTH", 80, (0, 0, 0), 1.2)

        if not scan_done:
            dots = "." * (int(t * 2) % 4)
            draw_center_text(frame, f"Scanning Bluetooth{dots}", 260, (80, 80, 80), 1)
        else:
            found = []

            for d in scan_result:
                user = match_user(d, users)
                if user:
                    found.append(user)

            if not found:
                draw_center_text(frame, "NO DEVICE FOUND", 260, (0, 0, 255), 1.2)
            else:
                user = found[0]
                draw_center_text(frame, "LOGIN SUCCESS", 220, (0, 180, 0), 1.3)
                draw_center_text(frame, user["name"], 300, (0, 0, 0), 1)

                cv2.imshow(window, frame)
                cv2.waitKey(1200)

                
                for i in range(25):
                    fade = (frame * (1 - i / 25)).astype(np.uint8)
                    cv2.imshow(window, fade)
                    cv2.waitKey(20)

                
                cv2.destroyWindow(window)
                print("LOGIN SUCCESS")
                return user

        cv2.imshow(window, frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            cv2.destroyWindow(window)
            print("LOGIN EXITED")
            return None

        if window_closed(window):
            cv2.destroyWindow(window)
            print("LOGIN CLOSED")
            return None


def run_login():
    return login_screen()