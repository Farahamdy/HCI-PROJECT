import cv2
import numpy as np
import csv
import os


img_lenses = cv2.imread("GUI/lenses.png", cv2.IMREAD_UNCHANGED)
img_blushers = cv2.imread("GUI/Blusher.png", cv2.IMREAD_UNCHANGED)
img_lipsticks = cv2.imread("GUI/lipstick.png", cv2.IMREAD_UNCHANGED)

PRODUCT_INFO = {
    "lenses": {
        "title": "Lenses",
        "desc": "Enhance your look.",
        "price": "$25.00",
        "csv_key": "Lenses",
        "img": img_lenses
    },
    "blushers": {
        "title": "Blushers",
        "desc": "A radiant glow.",
        "price": "$15.00",
        "csv_key": "Blushers",
        "img": img_blushers
    },
    "lipsticks": {
        "title": "Lipsticks",
        "desc": "Bold & beautiful.",
        "price": "$20.00",
        "csv_key": "Lipsticks",
        "img": img_lipsticks
    }
}


def load_shades_from_csv(filepath="./Admin/cosmo_shades.csv"):
    shades = {
        "Blushers": [],
        "Lipsticks": [],
        "Lenses": []
    }

    if not os.path.exists(filepath):
        print(f"Warning: '{filepath}' not found. Shades will be empty.")
        return shades

    with open(filepath, mode='r') as file:
        reader = csv.DictReader(file)

        for row in reader:
            cat = row.get('Category')

            if cat in shades:
                r, g, b = int(row['R']), int(row['G']), int(row['B'])
                shades[cat].append((b, g, r))

    return shades


PRODUCT_SHADES = load_shades_from_csv()


# ==========================================================
# DRAW PRODUCT DETAILS
# ==========================================================
def draw_product_details(canvas, x, y, w, h, product_id):

    if not product_id or product_id not in PRODUCT_INFO:
        return

    font = cv2.FONT_HERSHEY_SIMPLEX
    pen_color = (255, 255, 255)

    cv2.rectangle(canvas, (x, y), (x + w, y + h), pen_color, 2)

    info = PRODUCT_INFO[product_id]

    img = info["img"]
    img_h, img_w = 220, w - 20
    img_x, img_y = x + 10, y + 10

    cv2.rectangle(
        canvas,
        (img_x, img_y),
        (img_x + img_w, img_y + img_h),
        pen_color,
        1
    )

    if img is not None:
        resized_img = cv2.resize(img, (img_w, img_h))

        if resized_img.shape[2] == 4:
            alpha = resized_img[:, :, 3] / 255.0
            img_bgr = resized_img[:, :, :3]

            roi = canvas[img_y:img_y + img_h, img_x:img_x + img_w]

            for c in range(3):
                roi[:, :, c] = (
                    alpha * img_bgr[:, :, c] +
                    (1 - alpha) * roi[:, :, c]
                )

            canvas[img_y:img_y + img_h, img_x:img_x + img_w] = roi

        else:
            canvas[
                img_y:img_y + img_h,
                img_x:img_x + img_w
            ] = resized_img

    text_y = img_y + img_h + 35

    cv2.putText(
        canvas,
        info["title"],
        (x + 10, text_y),
        font,
        0.8,
        pen_color,
        2,
        cv2.LINE_AA
    )

    text_y += 30

    cv2.putText(
        canvas,
        info["desc"],
        (x + 10, text_y),
        font,
        0.5,
        pen_color,
        1,
        cv2.LINE_AA
    )

    text_y += 40

    cv2.putText(
        canvas,
        "Price: " + info["price"],
        (x + 10, text_y),
        font,
        0.7,
        pen_color,
        2,
        cv2.LINE_AA
    )

    text_y += 45

    cv2.putText(
        canvas,
        "Shades:",
        (x + 10, text_y),
        font,
        0.7,
        pen_color,
        2,
        cv2.LINE_AA
    )

    shades_list = PRODUCT_SHADES.get(info["csv_key"], [])

    swatch_size = 30
    swatch_spacing = 12
    swatch_start_x = x + 10
    swatch_y = text_y + 15

    for i, color_bgr in enumerate(shades_list):

        sx = swatch_start_x + i * (swatch_size + swatch_spacing)

        if sx + swatch_size > x + w - 10:
            break

        cv2.rectangle(
            canvas,
            (sx, swatch_y),
            (sx + swatch_size, swatch_y + swatch_size),
            color_bgr,
            -1
        )

        cv2.rectangle(
            canvas,
            (sx, swatch_y),
            (sx + swatch_size, swatch_y + swatch_size),
            pen_color,
            2
        )


# ==========================================================
# MAIN GUI
# ==========================================================
def draw_cosmo_interface(
    frame,
    current_product=None,
    status_text="Guest Mode",
    panel_side="right"
):

    fh, fw = frame.shape[:2]

    panel_w = 300
    top_pad = 90
    bottom_pad = 40

    # ======================================================
    # DYNAMIC SIDE
    # ======================================================
    if panel_side == "left":

        left_panel_w = panel_w
        right_panel_w = 40

        frame_x = left_panel_w

        panel_x = 20

    else:

        left_panel_w = 40
        right_panel_w = panel_w

        frame_x = left_panel_w

        panel_x = frame_x + fw + 20

    canvas_w = left_panel_w + fw + right_panel_w
    canvas_h = top_pad + fh + bottom_pad

    bg_color = (235, 180, 225)

    canvas = np.full(
        (canvas_h, canvas_w, 3),
        bg_color,
        dtype=np.uint8
    )

    font = cv2.FONT_HERSHEY_SIMPLEX
    pen_color = (255, 255, 255)

    # ======================================================
    # TITLE
    # ======================================================
    title_x = frame_x + (fw // 2) - 100

    cv2.putText(
        canvas,
        "COSMO MIRROR",
        (title_x, 50),
        font,
        1.4,
        pen_color,
        3,
        cv2.LINE_AA
    )

    # ======================================================
    # STATUS
    # ======================================================
    cv2.putText(
        canvas,
        status_text,
        (frame_x, 80),
        font,
        0.7,
        pen_color,
        2,
        cv2.LINE_AA
    )

    # ======================================================
    # CAMERA FRAME
    # ======================================================
    canvas[
        top_pad:top_pad + fh,
        frame_x:frame_x + fw
    ] = frame

    # ======================================================
    # PRODUCT PANEL
    # ======================================================
    draw_product_details(
        canvas,
        panel_x,
        top_pad,
        panel_w - 40,
        500,
        current_product
    )

    return canvas