import math

MENU_START = -math.pi * 3/4
MENU_END = math.pi * 3/4
ROTATION_SPEED = 0.1

class CircularMenu:
    def __init__(self):
        self.main_menu = ["Face", "Eyes", "Lips"]
        self.sub_menus = {
            "Face": ["Blush", "Foundation", "Contour"],
            "Eyes": ["Lenses", "Eyeliner","Eyeshadow"],
            "Lips": ["Lipstick", "Lip gloss", "Lip liner"]
        }
        self.selected_main = 0
        self.selected_sub = 0

        self.current_angle_main = 0
        self.target_angle_main = 0
        self.current_angle_sub = 0
        self.target_angle_sub = 0

        self.last_angle = 0
        self.last_y = 0

    def update_rotation(self):
        """Smooth rotation towards target."""
        self.current_angle_main += (self.target_angle_main - self.current_angle_main) * ROTATION_SPEED
        self.current_angle_sub += (self.target_angle_sub - self.current_angle_sub) * ROTATION_SPEED

    def select_next_main(self):
        self.selected_main = (self.selected_main + 1) % len(self.main_menu)
        self.selected_sub = 0
        self.target_angle_main -= 2*math.pi / len(self.main_menu)

    def select_prev_main(self):
        self.selected_main = (self.selected_main - 1) % len(self.main_menu)
        self.selected_sub = 0
        self.target_angle_main += 2*math.pi / len(self.main_menu)

    def select_next_sub(self):
        items = self.sub_menus[self.main_menu[self.selected_main]]
        self.selected_sub = (self.selected_sub + 1) % len(items)
        self.target_angle_sub -= 2*math.pi / len(items)

    def reset_sub(self):
        self.selected_sub = 0
        self.target_angle_sub = 0

    def update(self, markers):
        """Update menu selection from TUIO/gesture markers."""
        marker0 = marker1 = None
        for m in markers:
            if m.get("id") == 0:
                marker0 = m
            elif m.get("id") == 1:
                marker1 = m

        if marker0:
            angle = marker0.get("angle", 0)
            diff = angle - self.last_angle
            if abs(diff) > 0.05:
                if diff > 0:
                    self.select_next_main()
                else:
                    self.select_prev_main()
            self.last_angle = angle

        if marker1:
            y = marker1.get("y", 0)
            diff = y - self.last_y
            items = self.sub_menus[self.main_menu[self.selected_main]]
            if diff < -0.02:
                self.select_next_sub()
            elif diff > 0.02:
                self.reset_sub()
            self.last_y = y