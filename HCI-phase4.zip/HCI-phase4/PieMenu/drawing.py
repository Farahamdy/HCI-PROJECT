import cv2  
import numpy as np
import math

def draw_ring_slice(img, center, inner_r, outer_r, start_angle, end_angle, color):
    """Draw a ring segment (like a pie slice) on the image."""
    pts = []
    steps = 40  # smoother curve

    # Outer arc
    for i in range(steps + 1):
        angle = start_angle + (end_angle - start_angle) * i / steps
        x = int(center[0] + outer_r * math.cos(angle))
        y = int(center[1] + outer_r * math.sin(angle))
        pts.append([x, y])

    # Inner arc (reverse)
    for i in range(steps + 1):
        angle = end_angle - (end_angle - start_angle) * i / steps
        x = int(center[0] + inner_r * math.cos(angle))
        y = int(center[1] + inner_r * math.sin(angle))
        pts.append([x, y])

    pts = np.array(pts, np.int32)
    cv2.fillPoly(img, [pts], color)

def draw_item(img, text, center, radius, angle, selected=False):
    """Draw a circular menu item with text."""
    x = int(center[0] + radius * math.cos(angle))
    y = int(center[1] + radius * math.sin(angle))

    color = (0, 200, 120) if not selected else (0, 0, 255)
    cv2.circle(img, (x, y), 12, color, -1)

    cv2.putText(img, text, (x - 30, y + 25),
                cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)