import socket
import threading
import json

HOST = "localhost"
PORT = 5000
clients = []  

s = socket.socket()
s.bind((HOST, PORT))
s.listen(5)
print("Server listening on port", PORT)

def broadcast(message, exclude=None):
    for c in clients[:]:
        if c != exclude:
            try:
                c.sendall(message.encode())
            except:
                clients.remove(c)
                c.close()

def handle_client(conn, addr):
    buffer = ""
    print(f"Client connected: {addr}")
    clients.append(conn)

    try:
        while True:
            data = conn.recv(1024).decode()
            if not data:
                break
            buffer += data

            while "\n" in buffer:
                line, buffer = buffer.split("\n", 1)
                line = line.strip()
                if not line:
                    continue

                # Remove "Marker:" prefix if present
                if line.startswith("Marker:"):
                    line = line.replace("Marker:", "").strip()

                
                try:
                    try:
                        obj = json.loads(line)  
                    except json.JSONDecodeError:
                        print("error")        

                    # print("Marker:", obj)

                    broadcast(json.dumps(obj) + "\n")

                except Exception as e:
                    print("Failed to parse line:", line, "Error:", e)

    except Exception as e:
        print("Client error:", e)

    finally:
        print(f"Client disconnected: {addr}")
        if conn in clients:
            clients.remove(conn)
        conn.close()

while True:
    conn, addr = s.accept()
    threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()