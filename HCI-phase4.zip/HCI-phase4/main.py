import numpy as np  
import cv2
import threading
import queue
import socket
import json
import time
from collections import deque
from dataclasses import dataclass
from enum import Enum

# ===================== FILTER MODULES =====================
from media.detection_blush import process_frame as process_blush
from media.detection_lenses import process_frame as process_lens
from media.detection_lips import process_frame as process_lip
from media.detection_blush import blush_colors
from media.detection_lenses import lens_colors
from media.detection_lips import lip_colors

# ===================== UI  =====================
from PieMenu.menu import CircularMenu, MENU_START, MENU_END
from PieMenu.drawing import draw_ring_slice, draw_item
from GUI.gui import draw_cosmo_interface

# ===================== LOGIN =====================
from Database.bluetooth_detection import run_login
from faceid.face_auth import authenticate_from_frame, train_admin

# ===================== AI =====================
from FacialEmotion.facial import get_emotion_fast
from gaze.gaze_manager import GazeManager
from YOLO.objectTracking import ObjectSwipeDetector

# ===================== ADMIN =====================
from Admin.admin_panel import run_admin   

# ==========================================================
# CONFIG
# ==========================================================
CAM_WIDTH = 720
CAM_HEIGHT = 720

MODE_NONE = 0
MODE_LENS = 1
MODE_BLUSH = 2
MODE_LIP = 3
ROLE_UNKNOWN = "unknown"

# Control Source Priority (higher = more priority)
class ControlPriority(Enum):
    TUIO = 4      # Highest - explicit rotation
    OBJECT = 3    # Explicit product swipe
    GESTURE = 2   # Intentional hand gesture
    EMOTION = 1   # Passive emotion change
    NONE = 0

# ==========================================================
# IMPROVED APP STATE
# ==========================================================
@dataclass
class AppState:
    current_mode: int = MODE_NONE
    current_filter_name: str = "Original"
    current_shade: int = 0
    last_shade: int = 0
    
    # Control arbitration
    active_controller: ControlPriority = ControlPriority.EMOTION
    controller_owner: str = "EMOTION"  # Keep for backward compatibility
    controller_lock_timer: int = 0      # Lock controller for N frames
    last_interaction_time: float = 0.0  # Timestamp of last interaction
    
    # Performance monitoring
    fps_history: deque = None
    last_fps_time: float = 0.0
    
    def __post_init__(self):
        self.fps_history = deque(maxlen=30)
    
    # In the AppState class, increase the lock timer:

    def request_control(self, controller: ControlPriority, force: bool = False) -> bool:
        """Request control with priority-based arbitration"""
        now = time.time()
        
        # Force takeover for highest priority
        if force or controller.value > self.active_controller.value:
            self.active_controller = controller
            self.controller_owner = controller.name
            self.last_interaction_time = now
            self.controller_lock_timer = 45  # Increased from 15 to 45 frames (~1.5 seconds at 30fps)
            print(f"[CONTROL] {controller.name} took control (locked for {self.controller_lock_timer} frames)")
            return True
        
        # Same controller can maintain control and extend lock
        elif controller == self.active_controller:
            self.last_interaction_time = now
            self.controller_lock_timer = max(self.controller_lock_timer, 30)  # Extend to 30 frames minimum
            return True
        
        return False

    def release_control(self):
        """Release control back to emotion after timeout"""
        if self.controller_lock_timer <= 0:
            if self.active_controller != ControlPriority.EMOTION:
                old_controller = self.active_controller.name
                self.active_controller = ControlPriority.EMOTION
                self.controller_owner = "EMOTION"
                print(f"[CONTROL] Released from {old_controller} to EMOTION (lock expired)")
    def update(self):
        """Update timers and release control if needed"""
        if self.controller_lock_timer > 0:
            self.controller_lock_timer -= 1
        self.release_control()

app_state = AppState()

# ==========================================================
# THREADING WITH PERFORMANCE OPTIMIZATION
# ==========================================================
frame_lock = threading.Lock()
shared_frame = [None]
processed_frame = [None]

stop_event = threading.Event()
frame_queue = queue.Queue(maxsize=2)  # Increased for smoother processing

# Performance metrics
processing_times = deque(maxlen=30)

# ==========================================================
# FILTER MAP
# ==========================================================
FILTERS = {
    MODE_LENS: process_lens,
    MODE_BLUSH: process_blush,
    MODE_LIP: process_lip
}
PRODUCT_MAP = {
    MODE_LENS: "lenses",
    MODE_BLUSH: "blushers",
    MODE_LIP: "lipsticks"
}

# ==========================================================
# OPTIMIZED CAMERA THREAD
# ==========================================================
def camera_worker(cap):
    """Optimized camera capture with framerate limiting"""
    frame_time = 1/30  # Target 30 FPS
    last_frame = time.time()
    
    while not stop_event.is_set():
        ret, frame = cap.read()
        if not ret:
            continue
        
        # Limit framerate to reduce processing load
        now = time.time()
        if now - last_frame < frame_time:
            time.sleep(0.001)
            continue
        
        last_frame = now
        
        # Store frame without flipping (flip in display thread)
        with frame_lock:
            shared_frame[0] = frame.copy()

# ==========================================================
# OPTIMIZED PROCESS THREAD
# ==========================================================
def clear_frame_queue():
    while not frame_queue.empty():
        try:
            frame_queue.get_nowait()
        except queue.Empty:
            break

def process_worker():
    """Processing thread with performance monitoring"""
    while not stop_event.is_set():
        try:
            frame, mode, emotion, score, shade, app_state_ref = frame_queue.get(timeout=0.05)
        except queue.Empty:
            continue
        
        start_time = time.time()
        
        try:
            if mode in FILTERS:
                result = FILTERS[mode](
                    frame, emotion, score, shade, app_state_ref
                )
            else:
                result = frame
            
            # Track processing time
            proc_time = (time.time() - start_time) * 1000
            processing_times.append(proc_time)
            
            with frame_lock:
                processed_frame[0] = result
                
        except Exception as e:
            print(f"Processing Error: {e}")

threading.Thread(target=process_worker, daemon=True).start()

# ==========================================================
# IMPROVED TUIO CLIENT
# ==========================================================
active_markers = {}
marker_lock = threading.Lock()

def start_tuio_client(host="localhost", port=5000):
    def listen(stop_event):
        max_retries = 2
        retry_delay = 1
        
        for attempt in range(max_retries):
            soc = socket.socket()
            try:
                soc.connect((host, port))
                soc.settimeout(0.1)  # Non-blocking
                print(f"[TUIO] Connected to {host}:{port}")
                break
            except Exception as e:
                print(f"[TUIO] Connection attempt {attempt+1} failed: {e}")
                if attempt < max_retries - 1:
                    time.sleep(retry_delay)
                else:
                    print("[TUIO] Could not connect to TUIO server")
                    return
        
        buffer = ""
        last_heartbeat = time.time()
        
        while not stop_event.is_set():
            try:
                data = soc.recv(4096).decode()
                if data:
                    last_heartbeat = time.time()
                    buffer += data
                    
                    while "\n" in buffer:
                        line, buffer = buffer.split("\n", 1)
                        if not line.strip():
                            continue
                        
                        try:
                            marker = json.loads(line)
                            session = marker.get("session")
                            
                            with marker_lock:
                                if marker.get("type") == "remove":
                                    active_markers.pop(session, None)
                                else:
                                    active_markers[session] = marker
                        except:
                            pass
                else:
                    # Check for timeout
                    if time.time() - last_heartbeat > 3:
                        with marker_lock:
                            active_markers.clear()
                        break
                        
            except socket.timeout:
                continue
            except:
                break
        
        soc.close()
        print("[TUIO] Disconnected")
    
    threading.Thread(target=listen, args=(stop_event,), daemon=True).start()

def get_markers():
    with marker_lock:
        return list(active_markers.values())

start_tuio_client()

# ==========================================================
# IMPROVED TUIO CONTROLLER
# ==========================================================
class TUIOController:
    def __init__(self):
        self.last_angles = {}
        self.last_shade = -1
        self.angle_buffer = {}
        self.buffer_size = 3
        self.deadzone = 10
        self.smoothing = 0.7
        
        # Store references to shade data
        self.blush_shades = []
        self.lens_shades = []
        self.lip_shades = []
        
    def update_shade_data(self, blush_colors, lens_colors, lip_colors):
        """Update shade data from detection modules"""
        self.blush_shades = blush_colors
        self.lens_shades = lens_colors
        self.lip_shades = lip_colors
        
    def get_num_shades(self, app_state):
        """Get number of shades for current filter from actual loaded data"""
        if app_state.current_mode == MODE_BLUSH:
            return len(self.blush_shades)
        elif app_state.current_mode == MODE_LENS:
            return len(self.lens_shades)
        elif app_state.current_mode == MODE_LIP:
            return len(self.lip_shades)
        else:
            # If no filter selected, return 1 (no shades needed)
            return 1
    
    def update(self, markers, app_state, menu):
        """Update with smoothed angle detection"""
        ids = [m.get("id") for m in markers]
        
        # Update menu with markers
        menu.update(markers)
        menu.update_rotation()
        
        selected_main = menu.main_menu[menu.selected_main]
        selected_sub = menu.sub_menus[selected_main][menu.selected_sub]
        app_state.current_filter_name = selected_sub
        
        # Filter activation
        if selected_sub.lower() == "lenses":
            app_state.current_mode = MODE_LENS
        elif selected_sub.lower() == "blush":
            app_state.current_mode = MODE_BLUSH
        elif selected_sub.lower() == "lipstick":
            app_state.current_mode = MODE_LIP
        else:
            app_state.current_mode = MODE_NONE
        
        # Find active rotation marker
        rotation_marker_id = None
        if app_state.current_mode == MODE_LENS:
            rotation_marker_id = 2
        elif app_state.current_mode == MODE_BLUSH:
            rotation_marker_id = 3
        elif app_state.current_mode == MODE_LIP:
            rotation_marker_id = 4
        
        if rotation_marker_id is not None:
            for marker in markers:
                if marker.get("id") == rotation_marker_id:
                    if app_state.request_control(ControlPriority.TUIO):
                        raw_angle = marker.get("angle", 0)
                        degrees = np.degrees(raw_angle) % 360
                        
                        # Exponential moving average
                        last_angle = self.last_angles.get(rotation_marker_id, degrees)
                        smoothed_angle = self.smoothing * last_angle + (1 - self.smoothing) * degrees
                        self.last_angles[rotation_marker_id] = smoothed_angle
                        
                        # Get actual number of shades
                        num_shades = self.get_num_shades(app_state)
                        
                        if num_shades > 0:
                            # Map angle to shade (0 to num_shades-1)
                            shade_size = 360 / num_shades
                            new_shade = int(smoothed_angle // shade_size) % num_shades
                            
                            # Update only if changed
                            if new_shade != app_state.current_shade:
                                app_state.current_shade = new_shade
                                print(f"[TUIO] Angle: {smoothed_angle:.0f}° → Shade: {new_shade} (0-{num_shades-1})")
                    
                    break
# ==========================================================
# DRAW CIRCULAR MENU
# ==========================================================
def draw_circular_menu(frame, menu, w, h):
    cx, cy = w - 150, h - 170
    
    main_items = menu.main_menu
    step_main = (MENU_END - MENU_START) / len(main_items)
    
    for i, item in enumerate(main_items):
        start = MENU_START + i * step_main + 0.05
        end = start + step_main - 0.05
        mid = (start + end) / 2 + menu.current_angle_main
        
        color = (70, 70, 70) if i != menu.selected_main else (120, 120, 120)
        
        draw_ring_slice(
            frame, (cx, cy), 40, 90,
            start + menu.current_angle_main,
            end + menu.current_angle_main,
            color
        )
        
        draw_item(frame, item, (cx, cy), 65, mid, i == menu.selected_main)
    
    sub_items = menu.sub_menus[menu.main_menu[menu.selected_main]]
    step_sub = (MENU_END - MENU_START) / len(sub_items)
    
    for i, sub in enumerate(sub_items):
        start = MENU_START + i * step_sub + 0.05
        end = start + step_sub - 0.05
        mid = (start + end) / 2 + menu.current_angle_sub
        
        color = (50, 50, 50) if i != menu.selected_sub else (255, 100, 100)
        
        draw_ring_slice(
            frame, (cx, cy), 100, 150,
            start + menu.current_angle_sub,
            end + menu.current_angle_sub,
            color
        )
        
        draw_item(frame, sub, (cx, cy), 125, mid, i == menu.selected_sub)

# ==========================================================
# FACE LOGIN
# ==========================================================
face_detector = cv2.CascadeClassifier(
    "faceid/haarcascade_frontalface_default.xml"
)

def face_login_main(timeout=5):
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    start_time = time.time()
    saw_face = False
    last_result = None
    
    while True:
        ret, frame = cap.read()
        if not ret:
            continue
        
        result = authenticate_from_frame(frame, face_detector)
        cv2.imshow("Face Login", frame)
        cv2.waitKey(1)
        
        if result == "UNKNOWN_FACE":
            saw_face = True
            last_result = {"name": "Guest", "role": "guest"}
        elif isinstance(result, dict):
            cap.release()
            cv2.destroyAllWindows()
            return result
        
        if time.time() - start_time > timeout:
            cap.release()
            cv2.destroyAllWindows()
            if not saw_face:
                print("❌ No face detected → exit login")
                return None
            print("⚠ Unknown face → Guest mode")
            return last_result if last_result else {"name": "Guest", "role": "guest"}

def choose_login():
    print("1 -> Bluetooth Login")
    print("2 -> Face Login")
    
    while True:
        c = input("Select: ")
        if c == "1":
            user = run_login()
            if user:
                user["role"] = "user"
            return user
        elif c == "2":
            return face_login_main()

# ==========================================================
# MAIN APP WITH PERFORMANCE MONITORING
# ==========================================================
def main_app(user):
    menu = CircularMenu()
    gaze = GazeManager()
    swipe_detector = ObjectSwipeDetector("YOLO/best.pt")
    tuio = TUIOController()
    tuio.update_shade_data(blush_colors, lens_colors, lip_colors)
    
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAM_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAM_HEIGHT)
    cap.set(cv2.CAP_PROP_FPS, 30)  # Limit FPS
    
    print(f"Logged in as {user['name']} ({user['role']})")
    
    threading.Thread(target=camera_worker, args=(cap,), daemon=True).start()
    
    frame_counter = 0
    fps_timer = time.time()
    fps_display = 0
    
    try:
        while True:
            with frame_lock:
                frame = shared_frame[0].copy() if shared_frame[0] is not None else None
            
            if frame is None:
                continue
            
            frame_counter += 1
            
            # Calculate FPS
            if frame_counter % 30 == 0:
                elapsed = time.time() - fps_timer
                fps_display = 30 / elapsed if elapsed > 0 else 30
                fps_timer = time.time()
            
            # Process frame
            display = frame.copy()
            display = cv2.flip(display, 1)
            
            # Run detections at reduced frequency
            if frame_counter % 10 == 0:
                # Update object detector with control request
                swipe_detector.update(display, app_state)
            
            # Get emotion (cached, runs every 15 frames)
            emotion, score = get_emotion_fast(frame)
            
            # Update app state timers
            app_state.update()
            
            # Process TUIO
            markers = get_markers()
            if markers:
                tuio.update(markers, app_state, menu)
            
            # Check if emotion should take control (only if no active controller)
            if app_state.active_controller == ControlPriority.EMOTION:
                # Emotion-based shade change
                if emotion in ["sad"] and score > 0.6:
                    if app_state.controller_lock_timer == 0:
                        app_state.current_shade = (app_state.current_shade + 1) % 4
                        app_state.controller_lock_timer = 30
                        print(f"[EMOTION] Sad detected - shade changed to {app_state.current_shade}")
            
            # Queue processing
            mode = app_state.current_mode
            if mode != MODE_NONE:
                try:
                    clear_frame_queue()
                    frame_queue.put_nowait((
                        display.copy(),
                        mode,
                        emotion,
                        score,
                        app_state.current_shade,
                        app_state
                    ))
                except queue.Full:
                    pass
                
                with frame_lock:
                    if processed_frame[0] is not None:
                        display = processed_frame[0].copy()
            
            # Draw UI
            h, w = display.shape[:2]
            draw_circular_menu(display, menu, w, h)
            
            # # Draw FPS and control info
            # cv2.putText(display, f"FPS: {fps_display:.1f}", (10, 30),
            #            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
            # cv2.putText(display, f"Ctrl: {app_state.active_controller.name}", (10, 60),
            #            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 2)
            # cv2.putText(display, f"Shade: {app_state.current_shade}", (10, 90),
            #            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
            
            # Apply GUI for non-admin
            role = user.get("role", ROLE_UNKNOWN)
            if role != "admin":
                selected_main = menu.main_menu[menu.selected_main]
                selected_sub = menu.sub_menus[selected_main][menu.selected_sub]
                
                submenu_to_product = {
                    "lenses": "lenses",
                    "blush": "blushers",
                    "lipstick": "lipsticks"
                }
                current_product = submenu_to_product.get(selected_sub.lower(), None)
                status = f"Logged in as: {user['name']} ({role})"
                
                gaze_debug = gaze.process(frame)
                panel_side = gaze.get_ui_side()
                
                display = draw_cosmo_interface(
                    display, current_product=current_product,
                    status_text=status, panel_side=panel_side
                )
            
            cv2.imshow("Smart Mirror", display)
            
            key = cv2.waitKey(1) & 0xFF
            if key == 27 or key == ord("q"):
                break
               
    finally:
        gaze.save_heatmap()
        stop_event.set()
        cap.release()
        cv2.destroyAllWindows()

# ==========================================================
# RUN
# ==========================================================
# Train admin faces
train_admin("faceid/photo.jpg", "Admin1", role="admin")
train_admin("faceid/photo2.jpg", "Admin2", role="admin")
train_admin("faceid/photo3.jpeg", "Admin3", role="admin")
train_admin("faceid/photo4.jpeg", "Admin4", role="admin")
train_admin("faceid/photo5.jpeg", "Admin5", role="admin")


user = choose_login()
if user is None:
    exit(0)

role = user.get("role", ROLE_UNKNOWN)
print(f"Logged in as {user['name']} ({role})")

if role == "admin":
    stop_event.set()
    time.sleep(0.2)
    cv2.destroyAllWindows()
    run_admin()
else:
    main_app(user)