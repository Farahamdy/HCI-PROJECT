import csv
import os
import cv2
import mediapipe as mp
import numpy as np
from dollarpy import Recognizer, Point
import pickle
import random


# shared_types.py
from enum import Enum

# Control Source Priority (higher = more priority)
class ControlPriority(Enum):
    TUIO = 4      # Highest - explicit rotation
    OBJECT = 3    # Explicit product swipe
    GESTURE = 2   # Intentional hand gesture
    EMOTION = 1   # Passive emotion change
    NONE = 0

    
CSV_FILE = "./Admin/cosmo_shades.csv"

def load_shades(category="Blushers"):
    if not os.path.exists(CSV_FILE):
        return []

    colors = []

    with open(CSV_FILE, "r") as f:
        reader = csv.reader(f)
        next(reader)  # skip header

        for row in reader:
            if row[0] == category:
                r = int(row[1])
                g = int(row[2])
                b = int(row[3])
                colors.append((b, g, r))

    return colors

# ---------------- MediaPipe Setup ----------------
mp_face_mesh = mp.solutions.face_mesh
mp_hands = mp.solutions.hands

face_mesh = mp_face_mesh.FaceMesh(
    refine_landmarks=True,
    max_num_faces=1,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=2,
    min_detection_confidence=0.3,
    min_tracking_confidence=0.3
)

# ---------------- Load training data ----------------
with open("template/swipe_training.pkl", "rb") as f:
    templates, template_lengths = pickle.load(f)

recognizer = Recognizer(templates)

# ---------------- Blush Colors ----------------
blush_colors = load_shades("Blushers")

if not blush_colors:
    print("⚠️ No blush colors found in CSV. Using fallback color.")
    blush_colors = [(255, 255, 255)]  

# ---------------- Blush Landmarks ----------------
LEFT_CHEEK = [143,116,50,101,118,117,111]
RIGHT_CHEEK = [372,345,280,330,349,347,340]

# ---------------- Gesture Tracking ----------------
gesture_points = []
WINDOW_SIZE = 60
current_color = 0
change_trigger = False
cooldown = 0
smooth_shade = 0.0
last_shade = 0.0
SHADE_ALPHA = 0.25   # smoothing factor
DEAD_ZONE = 4        # degrees equivalent stability
    
# ---------------- Firework Particles ----------------
fireworks = []

# ---------------- Helper Functions ----------------
def resample_points(points, N):
    if len(points) == 0:
        return []
    xs = [p.x for p in points]
    ys = [p.y for p in points]
    t = np.linspace(0, 1, len(points))
    t_new = np.linspace(0, 1, N)
    xs_new = np.interp(t_new, t, xs)
    ys_new = np.interp(t_new, t, ys)
    return [Point(xs_new[i], ys_new[i]) for i in range(N)]

def apply_blush(frame, landmarks, indices, color, intensity=0.4):
    h, w, _ = frame.shape
    pts = [
        (
            int(landmarks.landmark[i].x * w),
            int(landmarks.landmark[i].y * h)
        )
        for i in indices
    ]
    pts = np.array(pts, np.int32)
    mask = np.zeros((h, w), dtype=np.uint8)
    cv2.fillPoly(mask, [pts], 255)
    mask = cv2.GaussianBlur(mask, (71, 71), 0)
    overlay = frame.copy()
    colored = np.full_like(frame, color)
    alpha = (mask / 255.0) * intensity
    for c in range(3):
        overlay[:, :, c] = (
            overlay[:, :, c] * (1 - alpha)
            + colored[:, :, c] * alpha
        )
    return overlay.astype(np.uint8)

# ---------------- Background Effect ----------------
def apply_background_effect(frame):
    global fireworks
    h, w = frame.shape[:2]

    if random.random() < 0.15:
        center_x = random.randint(100, w - 100)
        center_y = random.randint(80, h // 2)
        color = (
            random.randint(100, 255),
            random.randint(100, 255),
            random.randint(100, 255)
        )
        particles = []
        for i in range(40):
            angle = random.uniform(0, 2 * np.pi)
            speed = random.uniform(3, 8)
            particles.append({
                "x": center_x,
                "y": center_y,
                "dx": np.cos(angle) * speed,
                "dy": np.sin(angle) * speed,
                "life": random.randint(15, 30),
                "color": color
            })
        fireworks.append(particles)

    overlay = frame.copy()
    new_fireworks = []
    for particles in fireworks:
        alive_particles = []
        for p in particles:
            p["x"] += p["dx"]
            p["y"] += p["dy"]
            p["dy"] += 0.15
            p["life"] -= 1
            if p["life"] > 0:
                cv2.circle(
                    overlay,
                    (int(p["x"]), int(p["y"])),
                    3,
                    p["color"],
                    -1
                )
                alive_particles.append(p)
        if alive_particles:
            new_fireworks.append(alive_particles)
    fireworks = new_fireworks
    blurred = cv2.GaussianBlur(overlay, (9, 9), 0)
    result = cv2.addWeighted(frame, 0.7, blurred, 0.6, 0)
    return result

# ---------------- Main Processing Function ----------------
def process_frame(
    frame,
    emotion=None,
    score=0,
    shade=0,
    app_state=None
):
    global gesture_points
    global current_color
    global change_trigger
    global cooldown
    global smooth_shade
    global last_shade

    # =========================
    # UPDATE SHADE FROM APP_STATE
    # =========================
    if app_state is not None:
        # Use current_shade from app_state
        target = app_state.current_shade % len(blush_colors)
        
        # smooth interpolation
        smooth_shade = (
            SHADE_ALPHA * target +
            (1 - SHADE_ALPHA) * smooth_shade
        )
        
        # apply only if change is meaningful
        if abs(smooth_shade - last_shade) > (1.0 / len(blush_colors)):
            current_color = int(round(smooth_shade)) % len(blush_colors)
            last_shade = smooth_shade

    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # ---------------- Reduce Cooldown ----------------
    if cooldown > 0:
        cooldown -= 1

    # ---------------- Face Processing ----------------
    results_face = face_mesh.process(rgb_frame)

    if results_face.multi_face_landmarks:
        for landmarks in results_face.multi_face_landmarks:
            # ---------------- Positive Emotion ----------------
            if emotion in ["happy"] and score > 60:
                frame = apply_background_effect(frame)

            # ---------------- Negative Emotion (using app_state) ----------------
            if app_state is not None:
                if (
                        app_state.active_controller.value <= 1  # Only if emotion has control or lower
                        and emotion in ["sad"]
                        and score > 0.6
                    ):
                    if cooldown == 0:
                        app_state.current_shade = (app_state.current_shade + 1) % len(blush_colors)
                        cooldown = 20
                        print(f"[BLUSH] Emotion sad - shade changed to {app_state.current_shade}")

            # ---------------- Apply Blush ----------------
            frame = apply_blush(
                frame,
                landmarks,
                LEFT_CHEEK,
                blush_colors[current_color]
            )
            frame = apply_blush(
                frame,
                landmarks,
                RIGHT_CHEEK,
                blush_colors[current_color]
            )

    # ---------------- Hand Gesture Recognition ----------------
    results_hand = hands.process(rgb_frame)
    gesture_text = ""

    if results_hand.multi_hand_landmarks:
        for hand_landmarks in results_hand.multi_hand_landmarks:
            wrist = hand_landmarks.landmark[0]
            index_tip = hand_landmarks.landmark[8]
            gesture_points.append(Point(wrist.x, wrist.y))
            gesture_points.append(Point(index_tip.x, index_tip.y))
            if len(gesture_points) > WINDOW_SIZE:
                gesture_points = gesture_points[-WINDOW_SIZE:]
            if len(gesture_points) >= 20:
                try:
                    gesture_resampled = resample_points(
                        gesture_points,
                        template_lengths[0]
                    )
                    result = recognizer.recognize(gesture_resampled)
                    if result:
                        gesture_name, g_score = result
                        if app_state is not None:
                            # Only process gesture if not TUIO or OBJECT
                            if app_state.active_controller.value <= 2:  # Allow gesture if priority <= 2
                                if gesture_name == "Swipe Correct":
                                    if not change_trigger and cooldown == 0:
                                        app_state.request_control(ControlPriority.GESTURE)
                                        app_state.current_shade = (app_state.current_shade + 1) % len(blush_colors)
                                        change_trigger = True
                                        cooldown = 10
                                        print(f"[BLUSH] Gesture swipe - shade changed to {app_state.current_shade}")
                except:
                    gesture_text = ""
    else:
        gesture_points = []
        change_trigger = False

    return frame