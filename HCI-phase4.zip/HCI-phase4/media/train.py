import cv2
import mediapipe as mp
import numpy as np
from dollarpy import Recognizer, Template, Point
import pickle
import os

# ------------------------------
# MediaPipe Setup
# ------------------------------
mp_hands = mp.solutions.hands

hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=2,
    min_detection_confidence=0.3,
    min_tracking_confidence=0.3
)

# ------------------------------
# Swipe Recognition Setup
# ------------------------------
templates = []
template_lengths = []

def resample_points(points, N):
    if len(points) == 0:
        return []
    xs = [p.x for p in points]
    ys = [p.y for p in points]
    t = np.linspace(0, 1, len(points))
    t_new = np.linspace(0, 1, N)
    xs_new = np.interp(t_new, t, xs)
    ys_new = np.interp(t_new, t, ys)
    return [Point(xs_new[i], ys_new[i]) for i in range(N)]

def extract_points_from_video(video_path):
    cap_vid = cv2.VideoCapture(video_path)
    points = []

    while cap_vid.isOpened():
        ret, frame = cap_vid.read()
        if not ret:
            break
        results = hands.process(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        if results.multi_hand_landmarks :
            for hand_landmarks in results.multi_hand_landmarks:
                    wrist = hand_landmarks.landmark[0]
                    index_tip = hand_landmarks.landmark[8]
                    points.append(Point(wrist.x, wrist.y))
                    points.append(Point(index_tip.x, index_tip.y))

    cap_vid.release()
    return points

# ------------------------------
# Paths to training videos
# ------------------------------
correct_videos = [
    "video/swipe_correct_1.mp4",
    "video/swipe_correct_2.mp4"
]
incorrect_videos = [
    "video/swipe_incorrect_1.mp4",
    "video/swipe_incorrect_2.mp4"
]
# ------------------------------
# Extract points and create templates
# ------------------------------
pickle_file = "template/swipe_training.pkl"

for vid in correct_videos:
        pts = extract_points_from_video(vid)
        if pts:
            templates.append(Template("Swipe Correct", pts))
            template_lengths.append(len(pts))

for vid in incorrect_videos:
    pts = extract_points_from_video(vid)
    if pts:
        templates.append(Template("Swipe Incorrect", pts))
        template_lengths.append(len(pts))

# Save templates to pickle
with open(pickle_file, "wb") as f:
        pickle.dump((templates, template_lengths), f)
print("Training data saved to pickle.")    