import csv
import os
import cv2
import mediapipe as mp
import numpy as np
from dollarpy import Recognizer, Point
import pickle
import random


# shared_types.py
from enum import Enum

# Control Source Priority (higher = more priority)
class ControlPriority(Enum):
    TUIO = 4      # Highest - explicit rotation
    OBJECT = 3    # Explicit product swipe
    GESTURE = 2   # Intentional hand gesture
    EMOTION = 1   # Passive emotion change
    NONE = 0

CSV_FILE = "./Admin/cosmo_shades.csv"

def load_shades(category="Lipsticks"):
    if not os.path.exists(CSV_FILE):
        return []
    colors = []
    with open(CSV_FILE, "r") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            if row[0] == category:
                r = int(row[1])
                g = int(row[2])
                b = int(row[3])
                colors.append((b, g, r))
    return colors

# ---------------- MediaPipe Setup ----------------
mp_face_mesh = mp.solutions.face_mesh
mp_hands = mp.solutions.hands

face_mesh = mp_face_mesh.FaceMesh(
    refine_landmarks=True,
    max_num_faces=1,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=2,
    min_detection_confidence=0.3,
    min_tracking_confidence=0.3
)

# ---------------- Load training data ----------------
with open("template/swipe_training.pkl", "rb") as f:
    templates, template_lengths = pickle.load(f)

recognizer = Recognizer(templates)

# ---------------- Lipstick Colors ----------------
lip_colors = load_shades("Lipsticks")
if not lip_colors:
    print("⚠️ No lip colors found in CSV. Using fallback color.")
    lip_colors = [(255, 255, 255)]

# Lip landmark indices
LIP_INDICES = [61,146,91,181,84,17,314,405,321,375,291,
               308,324,318,402,317,14,87,178,88,95,
               185,40,39,37,0,267,269,270,409,291]

# ---------------- Gesture Tracking ----------------
gesture_points = []
WINDOW_SIZE = 60
current_color = 0
change_trigger = False
smooth_lip_shade = 0.0
last_lip_shade = 0.0
SHADE_ALPHA_LIP = 0.25
cooldown = 0

# ---------------- Firework Particles ----------------
fireworks = []

# ---------------- Helper Functions ----------------
def resample_points(points, N):
    if len(points) == 0:
        return []
    xs = [p.x for p in points]
    ys = [p.y for p in points]
    t = np.linspace(0, 1, len(points))
    t_new = np.linspace(0, 1, N)
    xs_new = np.interp(t_new, t, xs)
    ys_new = np.interp(t_new, t, ys)
    return [Point(xs_new[i], ys_new[i]) for i in range(N)]

def apply_lipstick(frame, face_landmarks, color, opacity=0.4):
    h, w, _ = frame.shape
    lip_points = []
    for i in LIP_INDICES:
        pt = face_landmarks.landmark[i]
        lip_points.append([int(pt.x * w), int(pt.y * h)])
    overlay = frame.copy()
    cv2.fillPoly(overlay, [np.array(lip_points, dtype=np.int32)], color)
    cv2.addWeighted(overlay, opacity, frame, 1 - opacity, 0, frame)

def apply_background_effect(frame):
    global fireworks
    h, w = frame.shape[:2]
    if random.random() < 0.15:
        center_x = random.randint(100, w - 100)
        center_y = random.randint(80, h // 2)
        color = (random.randint(100, 255), random.randint(100, 255), random.randint(100, 255))
        particles = []
        for i in range(40):
            angle = random.uniform(0, 2 * np.pi)
            speed = random.uniform(3, 8)
            particles.append({"x": center_x, "y": center_y, "dx": np.cos(angle) * speed, "dy": np.sin(angle) * speed, "life": random.randint(15, 30), "color": color})
        fireworks.append(particles)
    overlay = frame.copy()
    new_fireworks = []
    for particles in fireworks:
        alive_particles = []
        for p in particles:
            p["x"] += p["dx"]
            p["y"] += p["dy"]
            p["dy"] += 0.15
            p["life"] -= 1
            if p["life"] > 0:
                cv2.circle(overlay, (int(p["x"]), int(p["y"])), 3, p["color"], -1)
                alive_particles.append(p)
        if alive_particles:
            new_fireworks.append(alive_particles)
    fireworks = new_fireworks
    blurred = cv2.GaussianBlur(overlay, (9, 9), 0)
    result = cv2.addWeighted(frame, 0.7, blurred, 0.6, 0)
    return result

# ---------------- Main Processing Function ----------------
def process_frame(frame, emotion=None, score=0, shade=0, app_state=None):
    global gesture_points, current_color, change_trigger, cooldown, smooth_lip_shade, last_lip_shade

    # ---------------- Shade Control from app_state ----------------
    if app_state is not None and len(lip_colors) > 0:
        target = app_state.current_shade % len(lip_colors)
        smooth_lip_shade = (SHADE_ALPHA_LIP * target + (1 - SHADE_ALPHA_LIP) * smooth_lip_shade)
        diff = abs(smooth_lip_shade - last_lip_shade)
        if diff > 0.4:
            current_color = int(round(smooth_lip_shade)) % len(lip_colors)
            last_lip_shade = smooth_lip_shade
        
    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    if cooldown > 0:
        cooldown -= 1

    # ---------------- Face Processing ----------------
    results_face = face_mesh.process(rgb_frame)
    if results_face.multi_face_landmarks:
        for landmarks in results_face.multi_face_landmarks:
            if emotion in ["happy"] and score > 0.6:
                frame = apply_background_effect(frame)

            if app_state is not None:
                if app_state.active_controller.value <= 1 and emotion in ["sad"] and score > 0.6:
                    if cooldown == 0:
                        app_state.current_shade = (app_state.current_shade + 1) % len(lip_colors)
                        cooldown = 20
                        print(f"[LIP] Emotion sad - shade changed to {app_state.current_shade}")

            if len(lip_colors) > 0:
                apply_lipstick(frame, landmarks, lip_colors[current_color])

    # ---------------- Hand Gesture Recognition ----------------
    results_hand = hands.process(rgb_frame)
    gesture_text = ""

    if results_hand.multi_hand_landmarks:
        for hand_landmarks in results_hand.multi_hand_landmarks:
            wrist = hand_landmarks.landmark[0]
            index_tip = hand_landmarks.landmark[8]
            gesture_points.append(Point(wrist.x, wrist.y))
            gesture_points.append(Point(index_tip.x, index_tip.y))
            if len(gesture_points) > WINDOW_SIZE:
                gesture_points = gesture_points[-WINDOW_SIZE:]
            if len(gesture_points) >= 20:
                try:
                    gesture_resampled = resample_points(gesture_points, template_lengths[0])
                    if len(lip_colors) > 0:
                        result = recognizer.recognize(gesture_resampled)
                    else:
                        result = None
                    if result:
                        gesture_name, g_score = result
                        if app_state is not None:
                            if app_state.active_controller.value <= 2:
                                if gesture_name == "Swipe Correct":
                                    if not change_trigger and cooldown == 0:
                                        app_state.request_control(ControlPriority.GESTURE)
                                        app_state.current_shade = (app_state.current_shade + 1) % len(lip_colors)
                                        change_trigger = True
                                        cooldown = 10
                                        print(f"[LIP] Gesture swipe - shade changed to {app_state.current_shade}")
                except:
                    gesture_text = ""
    else:
        gesture_points = []
        change_trigger = False

    return frame