import csv
import os
import cv2
import mediapipe as mp
import numpy as np
from dollarpy import Recognizer, Point
import pickle
import random

# shared_types.py
from enum import Enum

# Control Source Priority (higher = more priority)
class ControlPriority(Enum):
    TUIO = 4      # Highest - explicit rotation
    OBJECT = 3    # Explicit product swipe
    GESTURE = 2   # Intentional hand gesture
    EMOTION = 1   # Passive emotion change
    NONE = 0



CSV_FILE = "./Admin/cosmo_shades.csv"

def load_shades(category="Lenses"):
    if not os.path.exists(CSV_FILE):
        return []
    colors = []
    with open(CSV_FILE, "r") as f:
        reader = csv.reader(f)
        next(reader)
        for row in reader:
            if row[0] == category:
                r = int(row[1])
                g = int(row[2])
                b = int(row[3])
                colors.append((b, g, r))
    return colors

# ---------------- MediaPipe Setup ----------------
mp_face_mesh = mp.solutions.face_mesh
mp_hands = mp.solutions.hands

face_mesh = mp_face_mesh.FaceMesh(
    refine_landmarks=True,
    max_num_faces=1,
    min_detection_confidence=0.5,
    min_tracking_confidence=0.5
)

hands = mp_hands.Hands(
    static_image_mode=False,
    max_num_hands=2,
    min_detection_confidence=0.3,
    min_tracking_confidence=0.3
)

# ---------------- Load training data ----------------
with open("template/swipe_training.pkl", "rb") as f:
    templates, template_lengths = pickle.load(f)

recognizer = Recognizer(templates)

# ---------------- Lens Colors ----------------
lens_colors = load_shades("Lenses")
if not lens_colors:
    print("⚠️ No lense colors found in CSV. Using fallback color.")
    lens_colors = [(255, 255, 255)]

# ---------------- Eye Landmarks ----------------
LEFT_IRIS = [474, 475, 476, 477]
RIGHT_IRIS = [469, 470, 471, 472]
LEFT_UPPER_EYELID = [159, 160, 161, 246]
LEFT_LOWER_EYELID = [145, 144, 153, 154]
RIGHT_UPPER_EYELID = [386, 387, 388, 263]
RIGHT_LOWER_EYELID = [374, 373, 380, 381]

# ---------------- Gesture Tracking ----------------
gesture_points = []
WINDOW_SIZE = 60
current_color = 0
change_trigger = False
cooldown = 0
smooth_lens_shade = 0.0
last_lens_shade = 0.0
SHADE_ALPHA_LENS = 0.25

# ---------------- Firework Particles ----------------
fireworks = []

# ---------------- Helper Functions ----------------
def resample_points(points, N):
    if len(points) == 0:
        return []
    xs = [p.x for p in points]
    ys = [p.y for p in points]
    t = np.linspace(0, 1, len(points))
    t_new = np.linspace(0, 1, N)
    xs_new = np.interp(t_new, t, xs)
    ys_new = np.interp(t_new, t, ys)
    return [Point(xs_new[i], ys_new[i]) for i in range(N)]

def eye_aspect_ratio(upper, lower):
    vertical1 = np.linalg.norm(np.array(upper[0]) - np.array(lower[0]))
    vertical2 = np.linalg.norm(np.array(upper[1]) - np.array(lower[1]))
    horizontal = np.linalg.norm(np.array(upper[0]) - np.array(upper[1]))
    return (vertical1 + vertical2) / (2.0 * horizontal)

def apply_lens_smooth(
    frame, landmarks, iris_indices, upper_eyelid, lower_eyelid,
    color, scale=0.8, min_scale=0.1, ear_threshold=0.25
):
    h, w, _ = frame.shape
    iris_points = [
        (int(landmarks.landmark[idx].x * w), int(landmarks.landmark[idx].y * h))
        for idx in iris_indices
    ]
    iris_points = np.array(iris_points)
    cx, cy = np.mean(iris_points, axis=0).astype(int)
    x_radius = max(int((np.max(iris_points[:, 0]) - np.min(iris_points[:, 0])) / 2), 1)
    y_radius = max(int((np.max(iris_points[:, 1]) - np.min(iris_points[:, 1])) / 2), 1)
    
    upper_points = [
        (int(landmarks.landmark[idx].x * w), int(landmarks.landmark[idx].y * h))
        for idx in upper_eyelid[:2]
    ]
    lower_points = [
        (int(landmarks.landmark[idx].x * w), int(landmarks.landmark[idx].y * h))
        for idx in lower_eyelid[:2]
    ]
    
    EAR = eye_aspect_ratio(upper_points, lower_points)
    lens_scale = min_scale if EAR < ear_threshold else min_scale + (scale - min_scale) * ((EAR - ear_threshold) / (1.0 - ear_threshold))
    lens_scale = min(lens_scale, scale)
    x_radius = max(int(x_radius * lens_scale), 1)
    y_radius = max(int(y_radius * lens_scale), 1)
    
    if x_radius < 1 or y_radius < 1:
        return
    
    iris_mask = np.zeros((h, w), dtype=np.uint8)
    cv2.ellipse(iris_mask, (cx, cy), (x_radius, y_radius), 0, 0, 360, 255, -1)
    
    eyelid_points = [
        (int(landmarks.landmark[idx].x * w), int(landmarks.landmark[idx].y * h))
        for idx in upper_eyelid + lower_eyelid
    ]
    eyelid_points = np.array(eyelid_points)
    eyelid_mask = np.zeros((h, w), dtype=np.uint8)
    cv2.fillPoly(eyelid_mask, [eyelid_points], 255)
    final_mask = cv2.bitwise_and(iris_mask, cv2.bitwise_not(eyelid_mask))
    
    overlay = frame.copy()
    yy, xx = np.where(final_mask == 255)
    for y, x in zip(yy, xx):
        dx = (x - cx) / x_radius
        dy = (y - cy) / y_radius
        r = np.sqrt(dx * dx + dy * dy)
        if r > 1:
            continue
        alpha = 0.2 + 0.6 * (1 - r)
        alpha *= np.random.uniform(0.85, 1.0)
        overlay[y, x] = np.clip(overlay[y, x] * (1 - alpha) + np.array(color) * alpha, 0, 255)
    
    pupil_radius = max(int(min(x_radius, y_radius) * 0.35), 1)
    cv2.circle(overlay, (cx, cy), pupil_radius, (0, 0, 0), -1)
    frame[final_mask == 255] = (overlay[final_mask == 255] * 0.7 + frame[final_mask == 255] * 0.3).astype(np.uint8)

def apply_background_effect(frame):
    global fireworks
    h, w = frame.shape[:2]
    if random.random() < 0.15:
        center_x = random.randint(100, w - 100)
        center_y = random.randint(80, h // 2)
        color = (random.randint(100, 255), random.randint(100, 255), random.randint(100, 255))
        particles = []
        for i in range(40):
            angle = random.uniform(0, 2 * np.pi)
            speed = random.uniform(3, 8)
            particles.append({"x": center_x, "y": center_y, "dx": np.cos(angle) * speed, "dy": np.sin(angle) * speed, "life": random.randint(15, 30), "color": color})
        fireworks.append(particles)
    overlay = frame.copy()
    new_fireworks = []
    for particles in fireworks:
        alive_particles = []
        for p in particles:
            p["x"] += p["dx"]
            p["y"] += p["dy"]
            p["dy"] += 0.15
            p["life"] -= 1
            if p["life"] > 0:
                cv2.circle(overlay, (int(p["x"]), int(p["y"])), 3, p["color"], -1)
                alive_particles.append(p)
        if alive_particles:
            new_fireworks.append(alive_particles)
    fireworks = new_fireworks
    blurred = cv2.GaussianBlur(overlay, (9, 9), 0)
    result = cv2.addWeighted(frame, 0.7, blurred, 0.6, 0)
    return result

# ---------------- Main Processing Function ----------------
def process_frame(frame, emotion=None, score=0, shade=0, app_state=None):
    global gesture_points, current_color, change_trigger, cooldown, smooth_lens_shade, last_lens_shade

    rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

    # ---------------- Shade Control from app_state ----------------
    if app_state is not None:
        target = app_state.current_shade % len(lens_colors)
        smooth_lens_shade = (SHADE_ALPHA_LENS * target + (1 - SHADE_ALPHA_LENS) * smooth_lens_shade)
        diff = abs(smooth_lens_shade - last_lens_shade)
        if diff > 0.5:
            current_color = int(round(smooth_lens_shade)) % len(lens_colors)
            last_lens_shade = smooth_lens_shade

    # ---------------- Reduce Cooldown ----------------
    if cooldown > 0:
        cooldown -= 1

    # ---------------- Face Processing ----------------
    results_face = face_mesh.process(rgb_frame)
    if results_face.multi_face_landmarks:
        for landmarks in results_face.multi_face_landmarks:
            if emotion in ["happy"] and score > 60:
                frame = apply_background_effect(frame)

            if app_state is not None:
                if app_state.active_controller.value <= 1 and emotion in ["sad"] and score > 0.6:
                    if cooldown == 0:
                        app_state.current_shade = (app_state.current_shade + 1) % len(lens_colors)
                        cooldown = 20
                        print(f"[LENS] Emotion sad - shade changed to {app_state.current_shade}")

            apply_lens_smooth(frame, landmarks, LEFT_IRIS, LEFT_UPPER_EYELID, LEFT_LOWER_EYELID, lens_colors[current_color])
            apply_lens_smooth(frame, landmarks, RIGHT_IRIS, RIGHT_UPPER_EYELID, RIGHT_LOWER_EYELID, lens_colors[current_color])

    # ---------------- Gesture Recognition ----------------
    results_hand = hands.process(rgb_frame)
    gesture_text = ""

    if results_hand.multi_hand_landmarks:
        for hand_landmarks in results_hand.multi_hand_landmarks:
            wrist = hand_landmarks.landmark[0]
            index_tip = hand_landmarks.landmark[8]
            gesture_points.append(Point(wrist.x, wrist.y))
            gesture_points.append(Point(index_tip.x, index_tip.y))
            if len(gesture_points) > WINDOW_SIZE:
                gesture_points = gesture_points[-WINDOW_SIZE:]
            if len(gesture_points) >= 20:
                try:
                    gesture_resampled = resample_points(gesture_points, template_lengths[0])
                    result = recognizer.recognize(gesture_resampled)
                    if result:
                        gesture_name, g_score = result
                        if app_state is not None:
                            if app_state.active_controller.value <= 2:
                                if gesture_name == "Swipe Correct":
                                    if not change_trigger and cooldown == 0:
                                        app_state.request_control(ControlPriority.GESTURE)
                                        app_state.current_shade = (app_state.current_shade + 1) % len(lens_colors)
                                        change_trigger = True
                                        cooldown = 10
                                        print(f"[LENS] Gesture swipe - shade changed to {app_state.current_shade}")
                except:
                    pass
    else:
        gesture_points = []
        change_trigger = False

    return frame