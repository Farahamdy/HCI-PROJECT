import cv2
import numpy as np
import json
import os
import time

from gaze.gaze_tracking import GazeTracking
from gaze.gaze_calibration import GazeCalibration
import matplotlib.pyplot as plt

class GazeManager:

    def __init__(self):

        self.gaze = GazeTracking()
        self.calib = GazeCalibration()
        # ==================================================
        # HEATMAP
        # ==================================================
        self.heatmap_points = []
        # =========================
        # SMOOTHING
        # =========================
        self.smooth_x = 0.5
        self.smooth_y = 0.5
        self.alpha = 0.15

        # =========================
        # UI POSITION
        # =========================
        self.ui_side = "center"

        self.SAVE_FILE = "gaze/ui_side.json"

        # =========================
        # HEATMAP TIMERS
        # =========================
        self.left_focus_time = 0
        self.right_focus_time = 0

        self.last_time = time.time()

        self.focus_threshold = 17  # seconds

        # =========================
        # LOAD SAVED SIDE
        # =========================
        if os.path.exists(self.SAVE_FILE):

            try:
                with open(self.SAVE_FILE, "r") as f:
                    data = json.load(f)
                    self.ui_side = data.get("side", "center")

            except:
                pass

    # ======================================================
    # SAVE SIDE
    # ======================================================
    def save_side(self):

        with open(self.SAVE_FILE, "w") as f:
            json.dump(
                {
                    "side": self.ui_side
                },
                f
            )

    # ======================================================
    # MAIN PROCESS
    # ======================================================
    def process(self, frame):

        self.gaze.refresh(frame)

        g = self.gaze.gaze_point()

        # ==================================================
        # CALIBRATION
        # ==================================================
        if not self.calib.calibrated:

            if g and self.calib.collecting:
                self.calib.add_sample(g)

        else:

            g = self.calib.predict(g)

            if g:
                gx, gy = g

                # FIX MIRROR INVERSION
                g = (gx, gy)

        # ==================================================
        # SMOOTHING
        # ==================================================
        if g:

            raw_x, raw_y = g

            self.smooth_x = (
                self.alpha * raw_x
                + (1 - self.alpha) * self.smooth_x
            )

            self.smooth_y = (
                self.alpha * raw_y
                + (1 - self.alpha) * self.smooth_y
            )

        x = self.smooth_x
        y = self.smooth_y
        # ==========================================
        # STORE GAZE POINTS
        # ==========================================
        self.heatmap_points.append((x, y))
        # ==================================================
        # REAL TIME HEATMAP TIMER
        # ==================================================
        now = time.time()
        dt = now - self.last_time
        self.last_time = now

        # LEFT SIDE LOOKING
        if x < 0.42:

            self.left_focus_time += dt

            # decay opposite side
            self.right_focus_time = max(
                0,
                self.right_focus_time - dt * 0.5
            )

        # RIGHT SIDE LOOKING
        elif x > 0.58:

            self.right_focus_time += dt

            self.left_focus_time = max(
                0,
                self.left_focus_time - dt * 0.5
            )

        # CENTER
        else:

            self.left_focus_time = max(
                0,
                self.left_focus_time - dt * 0.2
            )

            self.right_focus_time = max(
                0,
                self.right_focus_time - dt * 0.2
            )

        # ==================================================
        # SIDE SWITCHING
        # ==================================================
        old_side = self.ui_side

        if self.left_focus_time >= self.focus_threshold:
            self.ui_side = "left"

        elif self.right_focus_time >= self.focus_threshold:
            self.ui_side = "right"

        # SAVE IF CHANGED
        if old_side != self.ui_side:
            self.save_side()

        # ==================================================
        # DEBUG
        # ==================================================
        debug = {
            "gaze_x": round(x, 2),
            "left_time": round(self.left_focus_time, 1),
            "right_time": round(self.right_focus_time, 1),
            "ui_side": self.ui_side
        }

        return debug
        # ======================================================
    # SAVE HEATMAP IMAGE
    # ======================================================
    def save_heatmap(self):

        if len(self.heatmap_points) < 10:
            return

        points = np.array(self.heatmap_points)

        x = points[:, 0]
        y = points[:, 1]

        plt.figure(figsize=(6, 6))

        plt.hist2d(
            x,
            y,
            bins=60,
            range=[[0, 1], [0, 1]]
        )

        plt.gca().invert_yaxis()

        plt.colorbar(label="Attention Density")

        plt.title("User Gaze Heatmap")

        plt.xlabel("Horizontal Gaze")
        plt.ylabel("Vertical Gaze")

        plt.savefig("gaze/heatmap.png")

        np.save("gaze/heatmap_data.npy", points)

        plt.close()

        print("Heatmap saved.")
    # ======================================================
    # GET UI SIDE
    # ======================================================
    def get_ui_side(self):
        return self.ui_side