import numpy as np
import cv2


class GazeCalibration:
    """
    9-point gaze calibration system:
    maps (gaze_x, gaze_y) → screen coordinates
    """

    def __init__(self):

        self.gaze_samples = []
        self.screen_samples = []

        self.calibrated = False

        self.model_x = None
        self.model_y = None

        # ---------------- 9-POINT GRID ---------------- #
        self.points = [
            (0.1, 0.1), (0.5, 0.1), (0.9, 0.1),
            (0.1, 0.5), (0.5, 0.5), (0.9, 0.5),
            (0.1, 0.9), (0.5, 0.9), (0.9, 0.9)
        ]

        self.index = 0
        self.collecting = False

    # ---------------- CURRENT TARGET ---------------- #

    def get_current_target(self):
        return self.points[self.index]

    def next_point(self):

        self.index += 1

        if self.index >= len(self.points):
            self._train()
            self.calibrated = True
            return None

        return self.points[self.index]

    # ---------------- DATA COLLECTION ---------------- #

    def add_sample(self, gaze_point):

        if gaze_point is None:
            return

        sx, sy = self.get_current_target()

        self.gaze_samples.append(gaze_point)
        self.screen_samples.append((sx, sy))

    # ---------------- TRAIN MODEL ---------------- #

    def _train(self):

        gaze = np.array(self.gaze_samples)
        screen = np.array(self.screen_samples)

        A = np.hstack([gaze, np.ones((len(gaze), 1))])

        self.model_x, _, _, _ = np.linalg.lstsq(A, screen[:, 0], rcond=None)
        self.model_y, _, _, _ = np.linalg.lstsq(A, screen[:, 1], rcond=None)

    # ---------------- PREDICT ---------------- #

    def predict(self, gaze_point):

        if not self.calibrated or gaze_point is None:
            return gaze_point

        x, y = gaze_point

        A = np.array([x, y, 1])

        sx = np.dot(A, self.model_x)
        sy = np.dot(A, self.model_y)

        return (sx, sy)

    # ---------------- DRAW UI ---------------- #

    def draw(self, frame):

        # h, w = frame.shape[:2]

        # if self.calibrated:

        #     cv2.putText(frame, "CALIBRATED", (50, 50),
        #                 cv2.FONT_HERSHEY_SIMPLEX,
        #                 1, (0, 255, 0), 2)

        # else:

        #     tx, ty = self.get_current_target()

        #     px = int(tx * w)
        #     py = int(ty * h)

        #     cv2.circle(frame, (px, py), 20, (0, 0, 255), -1)

        #     cv2.putText(frame,
        #                 "Look at dot + SPACE (ENTER = next)",
        #                 (50, 50),
        #                 cv2.FONT_HERSHEY_SIMPLEX,
        #                 0.7,
        #                 (255, 255, 255),
        #                 2)

        return frame