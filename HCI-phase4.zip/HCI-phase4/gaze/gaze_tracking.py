import cv2
import mediapipe as mp
import numpy as np


class GazeTracking:
    """
    MediaPipe-based high-precision gaze tracker
    - continuous gaze output
    - micro eye movement detection
    - heatmap-ready coordinates
    """

    # Iris landmarks
    LEFT_IRIS = [474, 475, 476, 477]
    RIGHT_IRIS = [469, 470, 471, 472]

    # Eye corners (for normalization)
    LEFT_EYE_LEFT = 33
    LEFT_EYE_RIGHT = 133

    RIGHT_EYE_LEFT = 362
    RIGHT_EYE_RIGHT = 263

    def __init__(self):

        self.frame = None

        self.mp_face_mesh = mp.solutions.face_mesh

        self.face_mesh = self.mp_face_mesh.FaceMesh(
            max_num_faces=1,
            refine_landmarks=True,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )

        self.eye_left = None
        self.eye_right = None

        self.gaze_x = None
        self.gaze_y = None

    # ---------------- CORE UTILS ---------------- #
    def is_blinking(self):
        if self.frame is None:
            return False

        results = self.face_mesh.process(cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB))

        if not results.multi_face_landmarks:
            return False

        face = results.multi_face_landmarks[0]
        lm = face.landmark

        h, w = self.frame.shape[:2]

        # LEFT eye vertical distance
        top_l = np.array([lm[159].x * w, lm[159].y * h])
        bottom_l = np.array([lm[145].x * w, lm[145].y * h])

        left_eye_dist = np.linalg.norm(top_l - bottom_l)

        # RIGHT eye vertical distance
        top_r = np.array([lm[386].x * w, lm[386].y * h])
        bottom_r = np.array([lm[374].x * w, lm[374].y * h])

        right_eye_dist = np.linalg.norm(top_r - bottom_r)

        avg_dist = (left_eye_dist + right_eye_dist) / 2

        # threshold (you may tune this)
        return avg_dist < 4.5

    def _get_point(self, landmark, w, h):
        return np.array([int(landmark.x * w), int(landmark.y * h)])

    def _iris_center(self, iris_indices, landmarks, w, h):
        points = [
            self._get_point(landmarks[i], w, h)
            for i in iris_indices
        ]
        return np.mean(points, axis=0)

    def _eye_ratio(self, iris_coord, left_corner, right_corner):
        return (iris_coord - left_corner) / (right_corner - left_corner + 1e-6)

    # ---------------- MAIN ANALYSIS ---------------- #

    def _analyze(self):

        rgb = cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB)
        results = self.face_mesh.process(rgb)

        self.eye_left = None
        self.eye_right = None

        if not results.multi_face_landmarks:
            return

        face = results.multi_face_landmarks[0]
        landmarks = face.landmark

        h, w = self.frame.shape[:2]

        # ---------- IRIS CENTERS ----------
        left_iris = self._iris_center(self.LEFT_IRIS, landmarks, w, h)
        right_iris = self._iris_center(self.RIGHT_IRIS, landmarks, w, h)

        # ---------- EYE CORNERS ----------
        left_l = self._get_point(landmarks[self.LEFT_EYE_LEFT], w, h)
        left_r = self._get_point(landmarks[self.LEFT_EYE_RIGHT], w, h)

        right_l = self._get_point(landmarks[self.RIGHT_EYE_LEFT], w, h)
        right_r = self._get_point(landmarks[self.RIGHT_EYE_RIGHT], w, h)

        # ---------- NORMALIZED GAZE (KEY FIX) ----------
        left_x = self._eye_ratio(left_iris[0], left_l[0], left_r[0])
        right_x = self._eye_ratio(right_iris[0], right_l[0], right_r[0])

        left_y = self._eye_ratio(left_iris[1], left_l[1], left_r[1])
        right_y = self._eye_ratio(right_iris[1], right_l[1], right_r[1])

        self.gaze_x = (left_x + right_x) / 2
        self.gaze_y = (left_y + right_y) / 2

        # store pupils for visualization
        self.eye_left = {"pupil": left_iris.astype(int)}
        self.eye_right = {"pupil": right_iris.astype(int)}

    # ---------------- PUBLIC API ---------------- #

    def refresh(self, frame):
        self.frame = frame
        self._analyze()

    def gaze_point(self):
        """
        Returns continuous gaze position:
        (x, y) where 0 = left/top and 1 = right/bottom
        """
        if self.gaze_x is None or self.gaze_y is None:
            return None

        return (self.gaze_x, self.gaze_y)

    def gaze_delta(self, prev_point):
        """
        Detect micro movement between frames
        """
        if prev_point is None or self.gaze_point() is None:
            return (0, 0)

        return (
            self.gaze_x - prev_point[0],
            self.gaze_y - prev_point[1]
        )

    def is_left(self):
        if self.gaze_x is None:
            return False
        return self.gaze_x < 0.42

    def is_right(self):
        if self.gaze_x is None:
            return False
        return self.gaze_x > 0.58

    def is_center(self):
        if self.gaze_x is None:
            return False
        return not self.is_left() and not self.is_right()

    # ---------------- VISUALIZATION ---------------- #

    def annotated_frame(self):

        frame = self.frame.copy()

        if self.eye_left and self.eye_right:

            color = (0, 255, 0)

            lx, ly = self.eye_left["pupil"]
            rx, ry = self.eye_right["pupil"]

            # # crosshair left eye
            # cv2.line(frame, (lx - 5, ly), (lx + 5, ly), color, 2)
            # cv2.line(frame, (lx, ly - 5), (lx, ly + 5), color, 2)

            # # crosshair right eye
            # cv2.line(frame, (rx - 5, ry), (rx + 5, ry), color, 2)
            # cv2.line(frame, (rx, ry - 5), (rx, ry + 5), color, 2)

            # # show gaze point
            # if self.gaze_x is not None:

            #     text = f"Gaze: ({self.gaze_x:.2f}, {self.gaze_y:.2f})"

            #     cv2.putText(
            #         frame,
            #         text,
            #         (30, 50),
            #         cv2.FONT_HERSHEY_SIMPLEX,
            #         0.8,
            #         (0, 255, 0),
            #         2
            #     )

        return frame