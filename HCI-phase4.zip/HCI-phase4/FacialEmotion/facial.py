import cv2
from deepface import DeepFace
from collections import deque, Counter
# ---------------- Global State ----------------
frame_counter = 0
cached_emotion = None
cached_score = 0
emotion_buffer = deque(maxlen=15)
stable_emotion = None
stable_score = 0
# Emotion groups
NEGATIVE_EMOTIONS = ["sad"]
POSITIVE_EMOTIONS = ["happy","neutral"]

# ---------------- Core Emotion Detection ----------------
def detect_emotion(frame):
    try:
        # Resize frame for speed (VERY important for VS Code)
        small_frame = cv2.resize(frame, (320, 240))

        result = DeepFace.analyze(
            small_frame,
            actions=["emotion"],
            detector_backend="opencv",
            enforce_detection=False
        )

        # Handle list output
        if isinstance(result, list):
            result = result[0]

        emotion = result["dominant_emotion"]
        score = result["emotion"][emotion]

        # if score < 40:
        #     return None, 0

        return emotion, score

    except Exception as e:
        # Fail safely
        return None, 0

def stabilize_emotion(emotion, score):
    global stable_emotion, stable_score

    if emotion is None:
        return stable_emotion, stable_score

    # Add new emotion to history
    emotion_buffer.append(emotion)

    # Count most common emotion
    most_common = Counter(emotion_buffer).most_common(1)[0]

    emotion_name = most_common[0]
    count = most_common[1]

    # Require enough consistency
    if count >= 8:
        stable_emotion = emotion_name
        stable_score = score

    return stable_emotion, stable_score

# ---------------- Optimized Wrapper ----------------
def get_emotion_fast(frame):
    global frame_counter, cached_emotion, cached_score

    frame_counter += 1

    emotion = None
    score = 0

    if frame_counter % 15 == 0:
        emotion, score = detect_emotion(frame)

        if emotion:
            stable_emotion_result, stable_score_result = stabilize_emotion(emotion, score)

            cached_emotion = stable_emotion_result
            cached_score = stable_score_result

    return cached_emotion, cached_score


# ---------------- Helper: Emotion Type ----------------
def is_negative(emotion):
    return emotion in NEGATIVE_EMOTIONS


def is_positive(emotion):
    return emotion in POSITIVE_EMOTIONS


# ---------------- Optional Debug Drawing ----------------
def draw_emotion(frame, emotion, score):
    if emotion is None:
        return frame

    text = f"{emotion} ({score:.2f})"

    cv2.putText(
        frame,
        text,
        (20, 40),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (255, 255, 255),
        2
    )

    return frame