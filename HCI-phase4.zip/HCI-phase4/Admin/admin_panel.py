import cv2
import numpy as np
import csv
import os
import time
import mediapipe as mp
from mediapipe.tasks import python
from mediapipe.tasks.python import vision

CSV_FILE = "Admin/cosmo_shades.csv"

def load_shades_from_csv():
    """
    Loads ALL categories from CSV into a dictionary.
    """
    shades = {
        "Blushers": [],
        "Lipsticks": [],
        "Lenses": []
    }

    if not os.path.exists(CSV_FILE):
        return shades

    with open(CSV_FILE, "r") as f:
        reader = csv.reader(f)
        next(reader)

        for row in reader:
            if len(row) != 4:
                continue

            category = row[0].strip()
            r = int(row[1])
            g = int(row[2])
            b = int(row[3])

            if category in shades:
                shades[category].append((r, g, b))

    return shades

EXTRA_PALETTE = [
    (255, 105, 180), (220, 20, 60), (139, 0, 0), (255, 160, 122),
    (147, 112, 219), (75, 0, 130), (0, 250, 154), (70, 130, 180),
    (255, 215, 0), (255, 140, 0), (0, 191, 255), (32, 178, 170)
]

view_state = "MAIN"
current_category = ""
active_buttons = []
message_text = ""
message_timer = 0
update_target_index = -1 
current_button_index = 0

# --- Alternative Gesture Recognition using MediaPipe Solutions API (more reliable) ---
# This approach uses the simpler MediaPipe Hands solution instead of the Tasks API

detector = None
mp_hands = mp.solutions.hands
hands = None

try:
    # Initialize MediaPipe Hands with the simpler API
    hands = mp_hands.Hands(
        static_image_mode=False,
        max_num_hands=1,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5
    )
    print("✓ Hand tracking initialized successfully using MediaPipe Hands!")
    detector = "hands"  # Flag to indicate we're using the hands solution
except Exception as e:
    print(f"✗ Error initializing hand tracking: {e}")
    print("Gesture control will be disabled, but mouse control will still work.")
    hands = None

gesture_cooldown = 0.6    
click_cooldown = 1.0      
last_gesture_time = 0

# Debug variables
debug_show_landmarks = True
last_finger_count = -1
last_debug_time = 0

def save_shades(shades_dict):
    file = open(CSV_FILE, 'w', newline='')
    writer = csv.writer(file)
    writer.writerow(['Category', 'R', 'G', 'B'])
    
    for category in shades_dict:
        colors_list = shades_dict[category]
        for color in colors_list:
            r = color[0]
            g = color[1]
            b = color[2]
            writer.writerow([category, r, g, b])
            
    file.close()

db_shades = load_shades_from_csv()

# --- Functions for Mouse Clicks (Preserved) ---
def mouse_click(event, x, y, flags, param):
    global view_state, current_category, message_text, message_timer, update_target_index
    
    if event == cv2.EVENT_LBUTTONDOWN:
        
        for button in active_buttons:
            bx = button["x"]
            by = button["y"]
            bw = button["w"]
            bh = button["h"]
            
            if bx <= x <= bx + bw and by <= y <= by + bh:
                action = button["id"]
                process_gesture_action(action)

# --- Gesture Functions with Enhanced Debugging ---
def draw_hand_landmarks_simple(frame, hand_landmarks):
    """Draw hand landmarks using MediaPipe's drawing utilities"""
    h, w = frame.shape[:2]
    
    # Draw connections
    connections = mp_hands.HAND_CONNECTIONS
    for connection in connections:
        start_idx = connection[0]
        end_idx = connection[1]
        start = hand_landmarks.landmark[start_idx]
        end = hand_landmarks.landmark[end_idx]
        start_point = (int(start.x * w), int(start.y * h))
        end_point = (int(end.x * w), int(end.y * h))
        cv2.line(frame, start_point, end_point, (0, 255, 0), 2)
    
    # Draw landmarks
    for idx, landmark in enumerate(hand_landmarks.landmark):
        cx, cy = int(landmark.x * w), int(landmark.y * h)
        
        # Color finger tips differently for emphasis
        if idx in [4, 8, 12, 16, 20]:  # Finger tips
            color = (0, 255, 255)  # Yellow for fingertips
            radius = 8
        elif idx == 0:  # Wrist
            color = (255, 0, 255)  # Purple for wrist
            radius = 10
        else:
            color = (255, 0, 0)  # Red for other points
            radius = 4
        
        cv2.circle(frame, (cx, cy), radius, color, -1)
        # Add index number for debugging
        cv2.putText(frame, str(idx), (cx - 5, cy - 5), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)

def count_fingers_simple(hand_landmarks):
    """Count extended fingers using MediaPipe landmarks"""
    # Landmark indices
    thumb_tip = 4
    thumb_ip = 3
    index_tip = 8
    index_mcp = 5
    middle_tip = 12
    middle_mcp = 9
    ring_tip = 16
    ring_mcp = 13
    pinky_tip = 20
    pinky_mcp = 17
    
    count = 0
    
    # Thumb (check x coordinate - horizontal)
    if hand_landmarks.landmark[thumb_tip].x < hand_landmarks.landmark[thumb_ip].x:
        count += 1
    
    # Index finger
    if hand_landmarks.landmark[index_tip].y < hand_landmarks.landmark[index_mcp].y:
        count += 1
    
    # Middle finger
    if hand_landmarks.landmark[middle_tip].y < hand_landmarks.landmark[middle_mcp].y:
        count += 1
    
    # Ring finger
    if hand_landmarks.landmark[ring_tip].y < hand_landmarks.landmark[ring_mcp].y:
        count += 1
    
    # Pinky
    if hand_landmarks.landmark[pinky_tip].y < hand_landmarks.landmark[pinky_mcp].y:
        count += 1
    
    return count

def navigate_buttons(direction):
    global current_button_index, active_buttons
    if not active_buttons: return
    
    if direction == "RIGHT":
        current_button_index = (current_button_index + 1) % len(active_buttons)
    elif direction == "LEFT":
        current_button_index = (current_button_index - 1) % len(active_buttons)

def get_highlighted_button():
    if active_buttons and 0 <= current_button_index < len(active_buttons):
        return active_buttons[current_button_index]
    return None

def process_gesture_action(action):
    global view_state, current_category, message_text, message_timer, update_target_index, current_button_index
    
    
    if action in ["Blushers", "Lipsticks", "Lenses"]:
        current_category = action
        view_state = "CATEGORY"
        current_button_index = 0  
    
    elif action == "BACK":
        if view_state in ["ADD", "VIEW", "DELETE", "UPDATE"]:
            view_state = "CATEGORY"
        elif view_state == "UPDATE_CHOOSE":
            view_state = "UPDATE"
        else:
            view_state = "MAIN"
        current_button_index = 0  
    
    elif action == "MENU_VIEW": view_state, current_button_index = "VIEW", 0
    elif action == "MENU_ADD": view_state, current_button_index = "ADD", 0
    elif action == "MENU_UPDATE": view_state, current_button_index = "UPDATE", 0
    elif action == "MENU_DELETE": view_state, current_button_index = "DELETE", 0
        
    elif action.startswith("ADD_"):
        new_color = EXTRA_PALETTE[int(action.split("_")[1])]
        db_shades[current_category].append(new_color)
        save_shades(db_shades)
        message_text, message_timer, current_button_index = "SHADE ADDED", time.time(), 0
        
    elif action.startswith("DEL_"):
        db_shades[current_category].pop(int(action.split("_")[1]))
        save_shades(db_shades)
        message_text, message_timer, current_button_index = "SHADE DELETED", time.time(), 0

    elif action.startswith("UPD_TARGET_"):
        update_target_index = int(action.split("_")[2])
        view_state, current_button_index = "UPDATE_CHOOSE", 0

    elif action.startswith("UPD_NEW_"):
        new_color = EXTRA_PALETTE[int(action.split("_")[2])]
        db_shades[current_category][update_target_index] = new_color
        save_shades(db_shades)
        message_text, message_timer, view_state, current_button_index = "SHADE UPDATED", time.time(), "CATEGORY", 0

def draw_button(canvas, label, action_id, x, y, width, height, font):
    global active_buttons
    
    cv2.rectangle(canvas, (x, y), (x + width, y + height), (255, 255, 255), -1) 
    
    text_size = cv2.getTextSize(label, font, 0.7, 2)[0]
    text_width = text_size[0]
    text_height = text_size[1]
    
    text_x = x + int((width - text_width) / 2)
    text_y = y + int((height + text_height) / 2)
    
    cv2.putText(canvas, label, (text_x, text_y), font, 0.7, (235, 180, 225), 2, cv2.LINE_AA)
    
    new_button = {"id": action_id, "x": x, "y": y, "w": width, "h": height}
    active_buttons.append(new_button)

def draw_admin_interface(frame):
    global active_buttons
    
    active_buttons = []
    
    cam_h = frame.shape[0]
    cam_w = frame.shape[1]
    panel_w = 400
    
    canvas_w = cam_w + panel_w
    canvas_h = cam_h
    if canvas_h < 600:
        canvas_h = 600 
    
    canvas = np.full((canvas_h, canvas_w, 3), (235, 180, 225), dtype=np.uint8)
    
    cam_y = int((canvas_h - cam_h) / 2)
    canvas[cam_y : cam_y + cam_h, 0 : cam_w] = frame
    
    font = cv2.FONT_HERSHEY_SIMPLEX
    panel_x = cam_w
    
    cv2.putText(canvas, "COSMO ADMIN", (panel_x + 80, 60), font, 1.1, (255,255,255), 3, cv2.LINE_AA)
    
    if current_category != "":
        subtitle = current_category.upper() 
        cv2.putText(canvas, subtitle, (panel_x + 40, 100), font, 0.7, (255,255,255), 2, cv2.LINE_AA)

    start_y = 150

    if view_state == "MAIN":
        cv2.putText(canvas, "Select:", (panel_x + 60, start_y - 20), font, 0.7, (255,255,255), 2)
        
        draw_button(canvas, "BLUSHERS", "Blushers", panel_x + 60, start_y, 280, 50, font)
        draw_button(canvas, "LIPSTICKS", "Lipsticks", panel_x + 60, start_y + 70, 280, 50, font)
        draw_button(canvas, "LENSES", "Lenses", panel_x + 60, start_y + 140, 280, 50, font)

    elif view_state == "CATEGORY":
        draw_button(canvas, "VIEW SHADES", "MENU_VIEW", panel_x + 60, start_y, 280, 50, font)
        draw_button(canvas, "ADD SHADES", "MENU_ADD", panel_x + 60, start_y + 70, 280, 50, font)
        draw_button(canvas, "UPDATE SHADES", "MENU_UPDATE", panel_x + 60, start_y + 140, 280, 50, font)
        draw_button(canvas, "DELETE SHADES", "MENU_DELETE", panel_x + 60, start_y + 210, 280, 50, font)
        
        draw_button(canvas, "BACK", "BACK", panel_x + 60, start_y + 320, 280, 50, font)

    elif view_state in ["VIEW", "DELETE", "UPDATE"]:
        if view_state == "VIEW":
            header = "Current Shades:" 
        elif view_state == "DELETE":
            header = "Click a shade to DELETE:"
        else:
            header = "Click a shade to UPDATE:"
            
        cv2.putText(canvas, header, (panel_x + 40, start_y - 20), font, 0.7, (255, 255, 255), 2)
        
        shades_list = db_shades[current_category]
        
        if len(shades_list) == 0:
            cv2.putText(canvas, "No shades saved.", (panel_x + 60, start_y + 30), font, 0.6, (255, 255, 255), 2)
            
        swatch_size = 60
        margin = 30
        
        for i in range(len(shades_list)):
            rgb_color = shades_list[i]
            r, g, b = rgb_color[0], rgb_color[1], rgb_color[2]
            bgr_color = (b, g, r)
            
            row = int(i / 4)
            col = i % 4
            
            x = panel_x + 40 + (col * (swatch_size + margin))
            y = start_y + (row * (swatch_size + margin))
            
            cv2.rectangle(canvas, (x, y), (x + swatch_size, y + swatch_size), bgr_color, -1)
            cv2.rectangle(canvas, (x, y), (x + swatch_size, y + swatch_size), (0, 0, 0), 2) 
            
            if view_state == "DELETE":
                btn_id = "DEL_" + str(i)
                active_buttons.append({"id": btn_id, "x": x, "y": y, "w": swatch_size, "h": swatch_size})
                cv2.putText(canvas, "X", (x + 20, y + 40), font, 0.8, (255, 255, 255), 3)
                cv2.putText(canvas, "X", (x + 20, y + 40), font, 0.8, (0, 0, 0), 1)
                
            elif view_state == "UPDATE":
                btn_id = "UPD_TARGET_" + str(i)
                active_buttons.append({"id": btn_id, "x": x, "y": y, "w": swatch_size, "h": swatch_size})
                cv2.putText(canvas, "", (x + 20, y + 40), font, 0.8, (255, 255, 255), 3)
                cv2.putText(canvas, "", (x + 20, y + 40), font, 0.8, (0, 0, 0), 1)

        draw_button(canvas, "BACK", "BACK", panel_x + 60, start_y + 300, 280, 55, font)

    elif view_state in ["ADD", "UPDATE_CHOOSE"]:
        if view_state == "ADD":
            header = "Select a shade to ADD:"
        else:
            header = "Select the NEW color:"
            
        cv2.putText(canvas, header, (panel_x + 40, start_y - 20), font, 0.7, (255, 255, 255), 2)
        
        swatch_size = 60
        margin = 30
        
        for i in range(len(EXTRA_PALETTE)):
            rgb_color = EXTRA_PALETTE[i]
            r, g, b = rgb_color[0], rgb_color[1], rgb_color[2]
            bgr_color = (b, g, r) 
            
            row = int(i / 4)
            col = i % 4
            
            x = panel_x + 40 + (col * (swatch_size + margin))
            y = start_y + (row * (swatch_size + margin))
            
            cv2.rectangle(canvas, (x, y), (x + swatch_size, y + swatch_size), bgr_color, -1)
            cv2.rectangle(canvas, (x, y), (x + swatch_size, y + swatch_size), (0, 0, 0), 2)
            
            if view_state == "ADD":
                btn_id = "ADD_" + str(i)
            else:
                btn_id = "UPD_NEW_" + str(i)
                
            active_buttons.append({"id": btn_id, "x": x, "y": y, "w": swatch_size, "h": swatch_size})
            
            cv2.putText(canvas, "+", (x + 20, y + 40), font, 0.8, (255, 255, 255), 3)
            cv2.putText(canvas, "+", (x + 20, y + 40), font, 0.8, (0, 0, 0), 1)
            
        draw_button(canvas, "BACK", "BACK", panel_x + 60, start_y + 300, 280, 55, font)

    # Draw highlight for gesture-selected button
    highlighted_button = get_highlighted_button()
    if highlighted_button:
        bx, by, bw, bh = highlighted_button["x"], highlighted_button["y"], highlighted_button["w"], highlighted_button["h"]
        cv2.rectangle(canvas, (bx - 5, by - 5), (bx + bw + 5, by + bh + 5), (0, 255, 255), 4)

    time_passed = time.time() - message_timer
    if time_passed < 2.5 and message_text != "":
        cv2.putText(canvas, message_text, (panel_x + 60, canvas_h - 30), font, 0.7, (0, 150, 0), 2)

    return canvas

def run_admin():
    global last_gesture_time, current_button_index, hands, last_finger_count, last_debug_time
    
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)

    cv2.namedWindow("COSMO ADMIN PANEL")
    cv2.setMouseCallback("COSMO ADMIN PANEL", mouse_click)

   

    while True:
        success, frame = cap.read()
        if not success: 
            print("Failed to read from camera")
            break

        frame = cv2.flip(frame, 1) 
        frame = cv2.resize(frame, (640, 480))
        
        # Create a copy for drawing debug info
        debug_frame = frame.copy()
        
        # --- Process hand gestures using MediaPipe Hands ---
        gesture_info = "No hand detected"
        fingers_up = -1
        
        if hands is not None:
            # Convert BGR to RGB
            frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(frame_rgb)
            current_time = time.time()

            if results.multi_hand_landmarks:
                gesture_info = f"Hand detected! ({len(results.multi_hand_landmarks)} hand(s))"
                
                for hand_landmarks in results.multi_hand_landmarks:
                    # Draw detailed landmarks
                    draw_hand_landmarks_simple(debug_frame, hand_landmarks)
                    
                    fingers_up = count_fingers_simple(hand_landmarks)
                    
                    # Display finger count on hand
                    h, w = debug_frame.shape[:2]
                    wrist = hand_landmarks.landmark[0]
                    wrist_x, wrist_y = int(wrist.x * w), int(wrist.y * h)
                    cv2.putText(debug_frame, f"Fingers: {fingers_up}", 
                               (wrist_x - 30, wrist_y - 20),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                    
                    if current_time - last_gesture_time > gesture_cooldown:
                        if fingers_up == 1:
                            navigate_buttons("RIGHT")
                            last_gesture_time = current_time
                            
                        elif fingers_up == 2:
                            navigate_buttons("LEFT")
                            last_gesture_time = current_time
                            
                        elif fingers_up == 0:
                            highlighted_button = get_highlighted_button()
                            if highlighted_button:
                                process_gesture_action(highlighted_button["id"])
                                last_gesture_time = current_time + click_cooldown
            else:
                gesture_info = "No hand detected - Show your hand to camera"
        
        # Add debug overlay on the camera feed
        overlay = debug_frame.copy()
        
        # Draw semi-transparent debug panel
        cv2.rectangle(overlay, (10, 10), (300, 140), (0, 0, 0), -1)
        debug_frame = cv2.addWeighted(overlay, 0.6, debug_frame, 0.4, 0)
        
        # Add debug text
        cv2.putText(debug_frame, "=== DEBUG INFO ===", (15, 35), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 2)
        cv2.putText(debug_frame, gesture_info, (15, 65), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 0), 1)
        
        if fingers_up != -1:
            cv2.putText(debug_frame, f"Finger Count: {fingers_up}", (15, 95), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
        else:
            cv2.putText(debug_frame, f"Finger Count: --", (15, 95), 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 255), 2)
        
        cv2.putText(debug_frame, f"Selected Button: {current_button_index}", (15, 125), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        # Show the debug frame in the camera area
        canvas = draw_admin_interface(debug_frame)
        cv2.imshow("COSMO ADMIN PANEL", canvas)

        key = cv2.waitKey(1)
        if key == ord('q'):
            break
        elif key == ord('d'):
            debug_show_landmarks = not debug_show_landmarks

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    run_admin()