
import cv2
import numpy as np
from deepface import DeepFace
from scipy.spatial.distance import cosine
import json
import os

# ================= CONFIG =================
THRESHOLD = 0.85
DB_FILE = "faceid/face_db.json"

# ================= MEMORY =================
# structure:
# {
#   "name": {
#       "embedding": [...],
#       "role": "admin" or "user"
#   }
# }
face_db = {}


# ================= LOAD / SAVE =================
def save_db():
    with open(DB_FILE, "w") as f:
        json.dump(face_db, f)


def load_db():
    global face_db
    if os.path.exists(DB_FILE):
        with open(DB_FILE, "r") as f:
            face_db = json.load(f)


load_db()


# ================= TRAIN =================
def train_admin(photo_path, name, role="user"):
    img = cv2.imread(photo_path)

    if img is None:
        print(f"❌ Cannot load {photo_path}")
        return False

    emb = DeepFace.represent(
        img,
        model_name="Facenet",
        enforce_detection=True
    )

    face_db[name] = {
        "embedding": emb[0]["embedding"],
        "role": role
    }

    save_db()
    print(f"✓ Trained: {name} ({role})")
    return True


# ================= MATCH =================
def recognize(face_emb):
    best = None
    best_score = float("inf")

    for name, data in face_db.items():
        emb = data["embedding"]
        dist = cosine(face_emb, emb)

        if dist < best_score:
            best_score = dist
            best = name

    if best is None:
        return None

    conf = 1 - (best_score / 2)

    if conf < THRESHOLD:
        return None

    return {
        "name": best,
        "role": face_db[best]["role"]
    }


# ================= FACE DETECTION CORE =================
def authenticate_from_frame(frame, face_detector):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_detector.detectMultiScale(gray, 1.3, 5)
    if len(faces) == 0:
       return "NO_FACE"
    for (x, y, w, h) in faces:
        face = frame[y:y+h, x:x+w]

        try:
            emb = DeepFace.represent(
                face,
                model_name="Facenet",
                enforce_detection=False
            )

            result = recognize(emb[0]["embedding"])

            if result:
                return {
                    "name": result["name"],
                    "role": result["role"],
                    "box": (x, y, w, h)
                }

        except Exception as e:
            print("Face error:", e)

    return "UNKNOWN_FACE"